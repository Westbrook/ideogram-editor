import { html, nothing } from 'lit';
import { EditableFieldElement } from '../forms-private/editable-field.js';

/**
 * A native date control. Value, min and max are local calendar-date strings (YYYY-MM-DD), never timestamps.
 * The browser owns picker presentation and locale-specific editing.
 * @tagname en-date-input
 * @slot label - Visible field label; falls back to label.
 * @slot description - Supporting text; falls back to the description attribute/property.
 * @csspart field - Field layout.
 * @csspart label - Visible label.
 * @csspart control - Native date input.
 * @csspart focus-frame - Noninteractive field frame supporting the supplemental focus accent.
 * @csspart description - Supporting text.
 * @csspart error - Validation feedback.
 * @cssprop --en-control-background - Control background.
 * @cssprop --en-input-background - Field fill falling back to the shared control background.
 * @cssprop --en-input-color - Field text falling back to the shared control color.
 * @cssprop --en-control-radius - Control corner radius.
 * @cssprop --en-field-gap - Gap between label, control and supporting text.
 * @cssprop --en-input-inline-padding - Text-editor inline padding; takes precedence over shared control-inline-padding.
 * @cssprop --en-control-min-size - Minimum control block size.
 * @cssprop --en-input-focus-width - Width of the immediate input-family focus contour.
 * @cssprop --en-input-focus-color - Color of the immediate input-family focus contour.
 * @cssprop --en-input-focus-offset - Offset of the immediate input-family focus contour.
 * @cssprop --en-input-focus-halo-width - Width of the supplemental input-family focus halo.
 * @cssprop --en-input-focus-halo-color - Color of the supplemental input-family focus halo.
 * @cssprop --en-input-focus-accent-width - Thickness of the optional bottom focus accent on the field frame.
 * @cssprop --en-input-focus-accent-color - Color of the optional bottom focus accent on the field frame.
 * @cssprop --en-duration-focus-enter - Entry duration for supplemental focus decoration; the focus contour appears immediately.
 * @cssprop --en-duration-focus-exit - Exit duration for supplemental focus decoration.
 * @cssprop --en-ease-focus-enter - Entry easing for supplemental focus decoration.
 * @cssprop --en-ease-focus-exit - Exit easing for supplemental focus decoration.
 * @fires {import('../events.js').DraftInputEvent} en-input - Current native editing draft.
 * @fires {import('../events.js').FieldChangeEvent} en-change - Cancelable accepted-value change; provisional value and form data are available during dispatch.
 */
export class EnDateInput extends EditableFieldElement {
  static properties = {
    ...EditableFieldElement.properties,
    min: { type: String },
    max: { type: String },
    step: { type: Number },
  };
  declare min: string;
  declare max: string;
  /** Allowed date step in days. */
  declare step: number;
  constructor() {
    super();
    this.min = '';
    this.max = '';
    this.step = 1;
  }

  protected renderControl() {
    return html`<input id="control" class="en-input" part="control" type="date"
      name=${this.name} value=${this.defaultControlValue} min=${this.min || nothing} max=${this.max || nothing} step=${this.step}
      autocomplete=${this.autocomplete || nothing} ?disabled=${this.isDisabled} ?readonly=${this.readOnly} ?required=${this.required}
      aria-describedby=${this.describedBy} aria-invalid=${this.controlAriaInvalid}>`;
  }
}

declare global { interface HTMLElementTagNameMap { 'en-date-input': EnDateInput; } }

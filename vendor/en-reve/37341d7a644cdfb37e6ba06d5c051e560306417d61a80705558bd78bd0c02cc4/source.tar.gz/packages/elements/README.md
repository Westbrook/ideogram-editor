# En Rêve elements

Register individual elements through `@en-reve/elements/define/<name>.js`.
Class-only entrypoints are available at `@en-reve/elements/<name>.js`; the catalog
provides the dependency metadata used for selective registration and SSR.

Create eager native scopes with global fallback through `@en-reve/elements/element-scope.js`. See [scoped registry usage and ownership](SCOPED-REGISTRIES.md).

## Chat composition

`en-chat-message` renders an authored article with author, avatar, metadata, body,
attachments, actions and status slots. `en-chat-composer` composes a slotted
`en-textarea` or native textarea with attachment/tool/status slots and a shared send
button. Import `@en-reve/elements/define/chat-message.js` and
`@en-reve/elements/define/chat-composer.js` for registration.

Send and Control/Command + Enter request a cancelable `en-action` with
`detail.action === 'send'` and `detail.data.value`. Enter remains newline; IME
composition blocks send. `requestSend()` reports acceptance, not delivery. The
component never clears drafts/files. Use `sending` to guard duplicate requests
and let the application retain or clear the matching draft after its transport
settles. A replacement `send` slot triggers the same request; reflect its disabled
state on the supplied button. See [the integration contract](../../plans/chat-patterns.md).

## Typed events

Data notifications and tentative changes use `CustomEvent<Detail>` with exported
semantic event aliases. The API-01 feed, tree, table, navigation, overlay and editor
surfaces provide component-local listener maps. Native listener options, objects,
removal and AbortSignal work unchanged. No runtime class check is needed:

```ts
import type { PageChangeEvent, ActivityLoadRequestEvent } from '@en-reve/elements';

function onPage(event: PageChangeEvent): void {
  if (event.detail.proposed > lastAllowedPage) event.preventDefault();
}
feed.addEventListener('en-page-change', onPage);
feed.removeEventListener('en-page-change', onPage);

function onLoad(event: ActivityLoadRequestEvent): void {
  const {cursor, signal} = event.detail;
  event.respondWith(Promise.resolve().then(() => {
    signal.throwIfAborted();
    return application.loadHistory({cursor, signal});
  }));
}
feed.addEventListener('en-load-request', onLoad);
```

A typed listener still needs an ownership check when descendants can emit the same
bubbling event. `en-change` is not globally assigned a single payload type. In Lit,
annotate the handler signature and pass it to `@en-change`; native EventTarget
listeners and template bindings share the exported event types.

See [API-01 contracts and migration](../../plans/api-01-events.md) for tentative
state, load response ownership, lifecycle notifications and compatibility paths.

## Reusable component definitions

Each `definitions/<name>.js` entry exports one side-effect-free definition,
including the same dependency objects consumed by the catalog and the
`define/<name>.js` registration entry. Import a definition for selective scoped
registration or SSR without loading the entire catalog:

```ts
import {colorPickerDefinition} from '@en-reve/elements/definitions/color-picker.js';
import {registerDefinition} from '@en-reve/primitives/interactions/registration.js';

registerDefinition(registry, colorPickerDefinition);
```

`registry` is the application's chosen custom-element registry. The helper
registers dependencies first, skips an identical existing definition, and rejects
conflicting constructor identities before writing any definitions. Browser-level
validation errors are not rolled back. `catalog.js` exports all roots as
`definitions` plus explicit `registerAll(registry)`; merely importing the catalog,
a class entry, a definition entry or the main barrel registers nothing.

Authored-child policy stays explicit: `define/menu.js` does not register menu
items; import `define/menu-item.js` when authoring them. Likewise the neutral
editor trigger does not choose or register an editor implementation. Components
that generate their children, such as tree and color picker, retain those
dependencies. Add dependencies to the component's definition module once;
`npm run test:tooling` checks graph identity, entry coverage and cycles.

## Content ownership across collections

| Surface | Application content | Component-owned structure |
| --- | --- | --- |
| Tree data | Validated plain-text labels; no renderer callback | Tree and item semantics, hierarchy, selection and focus |
| Authored tree | Rich noninteractive `label`, decorative `prefix`/`suffix` slots | The same tree and item semantics |
| Activity `renderItem(item, index)` | Body and author/avatar/metadata/attachments/actions slot content | Managed `en-activity-item`; do not return another list-item wrapper |
| Carousel `renderItem(item, index)` | Mounted item content | `en-carousel-slide`, or `li` in list reading mode; do not return either wrapper |
| Table column `renderCell(item, index)` | Cell content | Native `th`/`td` and `tr`; do not return cell or row wrappers |

Equivalent authored/data validation and SSR presentation do not require every
component to expose a rich renderer. Native-anchor navigation and breadcrumbs
also retain their explicit content boundary; see [Link composition](src/link/README.md).

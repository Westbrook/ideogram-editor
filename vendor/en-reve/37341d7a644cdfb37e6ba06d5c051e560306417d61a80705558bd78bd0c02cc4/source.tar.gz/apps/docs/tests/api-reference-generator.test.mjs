import test from 'node:test';
import { generateAPIExamples } from '../scripts/generate-api-examples.mjs';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, rm, mkdir, copyFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { exportsClass, generateAPIReference, resolvePublicImport } from '../scripts/generate-api-reference.mjs';

test('public paths honor exact export exclusions and wildcard mappings', () => {
	const exports = { './*.js': { import: './dist/*.js', types: './dist/*.d.ts' }, './private.js': null };
	assert.equal(resolvePublicImport(exports, './button.js'), './dist/button.js');
	assert.equal(resolvePublicImport(exports, './define/button.js'), './dist/define/button.js');
	assert.throws(() => resolvePublicImport(exports, './private.js'), /No public ESM export/);
	assert.throws(() => resolvePublicImport(exports, './button.css'), /No public ESM export/);
});
test('CEM class identity follows aliases and both relative and package-root references; cycles terminate', () => {
	const modules = [
		{ path: 'src/public.ts', exports: [{ kind: 'js', name: 'PublicClass', declaration: { name: 'InternalClass', module: './nested/barrel.js' } }] },
		{ path: 'src/nested/barrel.ts', exports: [{ kind: 'js', name: 'InternalClass', declaration: { name: 'InternalClass', module: 'src/nested/element.ts' } }] },
		{ path: 'src/nested/element.ts', declarations: [{ name: 'InternalClass' }] },
		{ path: 'src/cycle.ts', exports: [{ kind: 'js', name: 'Cycle', declaration: { name: 'Cycle', module: './cycle.js' } }] },
	];
	assert.equal(exportsClass({ modules }, 'src/public.ts', 'PublicClass', 'src/nested/element.ts', 'InternalClass'), true);
	assert.equal(exportsClass({ modules }, 'src/public.ts', 'Missing', 'src/nested/element.ts', 'InternalClass'), false);
	assert.equal(exportsClass({ modules }, 'src/cycle.ts', 'Cycle', 'src/nested/element.ts', 'InternalClass'), false);
});
test('current verified package generates deterministic public references and linked authored examples', async () => {
	const workspaceRoot = process.env.API_REFERENCE_WORKSPACE_ROOT ?? resolve(fileURLToPath(new URL('../../../', import.meta.url)));
	const outputRoot = await mkdtemp(join(tmpdir(), 'en-api-reference-test-'));
	try {
		const first = await generateAPIReference({ workspaceRoot, outputRoot });
		const second = await generateAPIReference({ workspaceRoot, outputRoot });
		assert.equal(first.components, second.components);
		assert.ok(first.components > 0);
		assert.deepEqual(second.changedFiles, []);
		const module = await import(new URL(`file://${join(outputRoot, 'api-reference.js')}`));
		const reference = module.default;
		const receipt = JSON.parse(await readFile(join(workspaceRoot, 'packages/elements/custom-elements.json.receipt.json'), 'utf8'));
		assert.equal(reference.manifestDigest, receipt.manifestDigest);
		const nav = reference.components.find(component => component.tagName === 'en-navigation');
		assert.equal(nav.classImport, '@en-reve/elements/navigation.js');
		assert.equal(nav.definitionImport, '@en-reve/elements/define/navigation.js');
		assert.equal(nav.sections.properties.some(row => row.name === 'items'), false);
		assert.ok(nav.sections.slots.some(row => row.name === ''));
		assert.equal(nav.example.href, '/#specimen-navigation-sidebar');
		const picker = reference.components.find(component => component.tagName === 'en-combobox');
		assert.ok(picker.sections.properties.some(row => row.name === 'items'));
		assert.ok(picker.sections.properties.some(row => row.name === 'size' && row.inheritedFrom === 'EnElement'));
		assert.equal(picker.sections.methods.some(row => row.name === 'formResetCallback'), false);
	} finally { await rm(outputRoot, { recursive: true, force: true }); }
});

test('isolated content recipes register the skeleton rendered by the public placeholder helper', async () => {
 const workspaceRoot = process.env.API_REFERENCE_WORKSPACE_ROOT ?? resolve(fileURLToPath(new URL('../../../', import.meta.url)));
 const docsRoot = await mkdtemp(join(tmpdir(), 'en-api-examples-test-'));
 try {
  const generated = join(docsRoot, 'src/generated');
  await mkdir(generated, { recursive: true });
  for (const name of ['api-reference.js', 'specimens.js']) await copyFile(join(workspaceRoot, 'apps/docs/src/generated', name), join(generated, name));
  const { pages } = await generateAPIExamples({ workspaceRoot, docsRoot });
  const recipe = pages.find(page => page.id === 'content-recipes');
  assert.ok(recipe.tags.includes('en-skeleton'));
  assert.ok(recipe.definitions.includes('@en-reve/elements/define/skeleton.js'));
  assert.equal(recipe.tags.filter(tag => tag === 'en-skeleton').length, 1);
  assert.deepEqual((await generateAPIExamples({ workspaceRoot, docsRoot })).changedFiles, []);
 } finally { await rm(docsRoot, { recursive: true, force: true }); }
});

import {test,expect,type Page} from '@playwright/test';
import AxeBuilder from '@axe-core/playwright';
const url='/api-examples/rich-text.html';
const host=(page:Page)=>page.locator('#rich-brief');
const box=(page:Page)=>host(page).getByRole('textbox');
const bar=(page:Page)=>page.locator('#brief-toolbar');
const contextual=(page:Page)=>page.locator('#selection-toolbar');
const errors=new WeakMap<Page,string[]>();
test.beforeEach(({page})=>{const list:string[]=[];errors.set(page,list);page.on('pageerror',e=>list.push(e.message));});
test.afterEach(({page})=>expect(errors.get(page)).toEqual([]));
async function load(page:Page){await page.goto(url);await expect(box(page)).toHaveAttribute('contenteditable','true');await expect(page.locator('en-api-example-app')).not.toHaveAttribute('data-ssr');await page.waitForFunction(()=>document.documentElement.hasAttribute('data-example-standalone'));}
async function select(page:Page,text='Alpha beta',backwards=false){
 await host(page).evaluate((el:any,text)=>{el.value=text;el.focus();},text);await expect(host(page)).toHaveJSProperty('value',text);await box(page).scrollIntoViewIfNeeded();
 await box(page).evaluate((el,backwards)=>{const node=el.querySelector('p')!.firstChild!;const length=node.textContent!.length;const s=document.getSelection()!;s.setBaseAndExtent(node,backwards?length:0,node,backwards?0:length);},backwards);
 await expect(contextual(page).locator('.base')).toBeVisible();
}
test('semantic SSR content is readable before hydration and initial formatting survives',async({page,browser})=>{
 const context=await browser.newContext({javaScriptEnabled:false});try{const p=await context.newPage();await p.goto(url);await expect(host(p).getByRole('heading',{name:'A new direction'})).toBeVisible();await expect(host(p).locator('strong')).toHaveText('Make it yours.');await expect(box(p)).not.toHaveAttribute('contenteditable','true');}finally{await context.close();}
 await load(page);await expect(host(page).getByRole('heading',{name:'A new direction'})).toBeVisible();await expect(host(page).locator('strong')).toHaveText('Make it yours.');
});
test('persistent and contextual commands preserve backward selection and share undo history',async({page})=>{
 await load(page);await select(page,'Alpha beta',true);await contextual(page).getByRole('button',{name:'Bold',exact:true}).click();await expect(host(page).locator('strong')).toHaveText('Alpha beta');
 await bar(page).getByRole('button',{name:'Undo',exact:true}).click();await expect(host(page).locator('strong')).toHaveCount(0);
 await bar(page).getByRole('button',{name:'Redo',exact:true}).click();await expect(host(page).locator('strong')).toHaveText('Alpha beta');
 await bar(page).getByRole('button',{name:'Heading',exact:true}).click();await expect(host(page).getByRole('heading',{name:'Alpha beta'})).toBeVisible();
 await bar(page).getByRole('button',{name:'Paragraph',exact:true}).click();await expect(host(page).locator('p')).toHaveText('Alpha beta');
});
test('link editor retains a bookmark, validates URLs and Escape restores focus',async({page})=>{
 await load(page);await select(page);await bar(page).getByRole('button',{name:'Link',exact:true}).click();await bar(page).getByRole('textbox',{name:'Link URL'}).fill('javascript:alert(1)');await bar(page).getByRole('button',{name:'Apply link'}).click();await expect(bar(page).getByRole('alert')).toBeVisible();
 await bar(page).getByRole('textbox',{name:'Link URL'}).fill('https://example.com/brief');await bar(page).getByRole('button',{name:'Apply link'}).click();await expect(host(page).locator('a')).toHaveAttribute('href','https://example.com/brief');
 await box(page).press('Alt+F10');await expect(bar(page).getByRole('button',{name:'Bold',exact:true})).toBeFocused();await page.keyboard.press('Escape');await expect(box(page)).toBeFocused();
});
test('same providers insert in token, standalone rich and composer; action-only completion and snapshot',async({page})=>{
 await load(page);
 for(const id of ['rich-brief','rich-reply','plain-reply']){
  const editor=page.locator('#'+id);await editor.evaluate((el:any)=>{el.value='';el.focus();});const input=editor.getByRole('textbox');await input.pressSequentially('@Cov');await editor.getByRole('option',{name:'Cover study',exact:true}).waitFor();await input.press('Enter');await expect(editor.locator('[data-token]')).toHaveCount(1);await expect(editor).toHaveJSProperty('value','@Cover study');await expect(editor.locator('[part~=token-content]')).toHaveText('@Cover study');
  await editor.evaluate((el:any)=>{el.value='';el.focus();});await input.pressSequentially('/rev');await editor.getByRole('option',{name:'Review tool',exact:true}).waitFor();await input.press('Enter');await expect(editor.locator('[part~=token-content]')).toHaveText('/review');await expect(editor).toHaveJSProperty('value','/review');
 }
 await page.locator('#rich-reply').evaluate((el:any)=>{el.value='';el.focus();});const reply=page.locator('#rich-reply').getByRole('textbox');await reply.pressSequentially('/out');await reply.press('Enter');await expect(page.getByRole('status',{name:'Editor result'})).toContainText('outline');await expect(page.locator('#rich-reply')).toHaveJSProperty('value','');
 await reply.pressSequentially('Rich message');await page.getByRole('button',{name:'Send message',exact:true}).click();await expect(page.getByRole('status',{name:'Editor result'})).toContainText('Rich message');
});
test('demo action feedback preserves edited brief content and history until explicit reset',async({page})=>{
 await load(page);
 const input=box(page);
 await input.click();await input.press('ControlOrMeta+a');await input.pressSequentially('My edited brief ');
 await expect(host(page)).toHaveJSProperty('value','My edited brief ');
 await input.pressSequentially('/out');
 await host(page).getByRole('option',{name:'Outline action',exact:true}).click();
 await expect(page.getByRole('status',{name:'Editor result'})).toContainText('outline');
 await expect(host(page)).toHaveJSProperty('value','My edited brief ');
 await bar(page).getByRole('button',{name:'Undo',exact:true}).click();
 await expect(host(page)).toHaveJSProperty('value','My edited brief /out');
 await bar(page).getByRole('button',{name:'Redo',exact:true}).click();
 await input.pressSequentially('/rev');await input.press('Enter');
 await expect(host(page)).toHaveJSProperty('value','My edited brief /review');
 const saved=await host(page).evaluate((el:any)=>el.document);
 const reply=page.locator('#rich-reply').getByRole('textbox');
 await reply.click();await reply.pressSequentially('Reply /out');await reply.press('Enter');
 await expect(page.locator('#rich-reply')).toHaveJSProperty('value','Reply ');
 await page.getByRole('button',{name:'Send message',exact:true}).click();
 await expect(page.getByRole('status',{name:'Editor result'})).toContainText('Snapshot ready');
 await expect(host(page)).toHaveJSProperty('document',saved);
 await page.getByRole('button',{name:'Reset brief',exact:true}).click();
 await expect(host(page).getByRole('heading',{name:'A new direction'})).toBeVisible();
});
test('triple-click selects the whole rich document for copy and replacement without changing history',async({page})=>{
 await load(page);
 await host(page).evaluate((el:any)=>{
  el.document={type:'en-rich-text',version:1,doc:{type:'doc',content:[
   {type:'heading',attrs:{level:2},content:[{type:'text',text:'Draft title'}]},
   {type:'paragraph',content:[{type:'text',text:'Select this paragraph '},{type:'token',attrs:{run:{kind:'token',id:'review-token',type:'tool',text:'/review',label:'Review',data:{tool:'review'}}}}]},
   {type:'bullet_list',content:[{type:'list_item',content:[{type:'paragraph',content:[{type:'text',text:'Final list item'}]}]}]},
  ]}};
  el.changeCount=0;el.addEventListener('en-change',()=>el.changeCount++);
 });
 const saved=await host(page).evaluate((el:any)=>el.document);
 const text=await host(page).evaluate((el:any)=>el.value);
 await host(page).locator('.mount p').first().click({clickCount:3,position:{x:25,y:8}});
 await expect(box(page)).toBeFocused();await expect(host(page)).toHaveJSProperty('hasSelection',true);
 await expect(host(page)).toHaveJSProperty('changeCount',0);
 expect(await host(page).evaluate((el:any)=>el.getCommandState('undo').enabled)).toBe(false);
 const copied=await box(page).evaluate(el=>{
  const data=new DataTransfer();const event=new Event('copy',{bubbles:true,composed:true,cancelable:true});
  Object.defineProperty(event,'clipboardData',{value:data});el.dispatchEvent(event);return {text:data.getData('text/plain'),html:data.getData('text/html')};
 });
 expect(copied.text).toBe(text);expect(copied.html).toContain('Draft title');expect(copied.html).toContain('Final list item');
 await box(page).pressSequentially('Replacement');await expect(host(page)).toHaveJSProperty('value','Replacement');
 await bar(page).getByRole('button',{name:'Undo',exact:true}).click();await expect(host(page)).toHaveJSProperty('document',saved);
});
test('triple-click includes offscreen content in readonly drafts; single and double clicks stay local',async({page})=>{
 await load(page);await page.getByRole('button',{name:'Load long drafts',exact:true}).click();
 const paragraph=host(page).locator('.mount p').first();
 await paragraph.dblclick({position:{x:25,y:8}});
 const word=await box(page).evaluate(()=>document.getSelection()?.toString()??'');expect(word.length).toBeGreaterThan(0);expect(word).not.toContain('Paragraph 40');
 // A new pointer position starts a separate click sequence.
 await paragraph.click({position:{x:120,y:8}});await expect(host(page)).toHaveJSProperty('hasSelection',false);
 await host(page).evaluate((el:any)=>el.readOnly=true);
 await expect(box(page)).toHaveAttribute('contenteditable','false');
 await paragraph.click({clickCount:3,position:{x:200,y:8}});
 const selected=await box(page).evaluate(()=>document.getSelection()?.toString()??'');expect(selected).toContain('Paragraph 1:');expect(selected).toContain('Paragraph 40:');
 await expect(host(page).getByRole('listbox')).not.toBeVisible();
});
test('authoritative writes and canceled commits reject stale bookmarks; unsafe documents are rejected',async({page})=>{
 await load(page);await select(page);
 const result=await host(page).evaluate((el:any)=>{
  const bookmark=el.captureBookmark();el.value='Author replacement';const stale=el.execute('bold',undefined,bookmark);
  el.addEventListener('en-change',(event:Event)=>event.preventDefault(),{once:true});const cancel=el.execute('heading');const afterCancel=el.document;
  el.addEventListener('en-change',()=>{el.value='Latest author';},{once:true});el.execute('heading');
  let unsafe=false;try{el.document={type:'en-rich-text',version:1,doc:{type:'doc',content:[{type:'paragraph',content:[{type:'text',text:'bad',marks:[{type:'link',attrs:{href:'javascript:alert(1)'}}]}]}]}};}catch{unsafe=true;}
  return {stale,cancel,afterCancel,final:el.value,unsafe};
 });
 expect(result.stale).toBe(false);expect(result.cancel).toBe(false);expect(result.afterCancel.doc.content[0].type).toBe('paragraph');expect(result.final).toBe('Latest author');expect(result.unsafe).toBe(true);
});
test('late async providers cannot overwrite new input or author content',async({page})=>{
 await load(page);await host(page).evaluate((el:any)=>{el.value='';el.registerExtension({id:'async',trigger:'!',label:'Delayed',provide:({signal}:any)=>new Promise(resolve=>{el.finish=()=>resolve([{id:'old',label:'Old',insert:[{kind:'text',text:'wrong'}]}]);el.signal=signal;})});el.focus();});
 await box(page).pressSequentially('!');await expect(host(page).getByRole('status')).toContainText('Loading');await host(page).evaluate((el:any)=>{el.value='New author content';el.finish();});await expect(host(page)).toHaveJSProperty('value','New author content');await expect(host(page).getByRole('option')).toHaveCount(0);expect(await host(page).evaluate((el:any)=>el.signal.aborted)).toBe(true);
});
test('readonly, disabled, composition guards and disconnect clean up editor state',async({page})=>{
 await load(page);await host(page).evaluate((el:any)=>el.readOnly=true);await expect(box(page)).toHaveAttribute('contenteditable','false');expect(await host(page).evaluate((el:any)=>el.execute('heading'))).toBe(false);
 await host(page).evaluate((el:any)=>{el.readOnly=false;el.disabled=true;});await expect(box(page)).toHaveAttribute('tabindex','-1');
 await host(page).evaluate((el:any)=>{el.disabled=false;el.value='Before';el.focus();});await box(page).dispatchEvent('compositionstart');expect(await host(page).evaluate((el:any)=>el.execute('bold'))).toBe(false);await host(page).evaluate((el:any)=>el.value='After IME');await box(page).dispatchEvent('compositionend');await expect(host(page)).toHaveJSProperty('value','After IME');
 await host(page).evaluate(el=>{const parent=el.parentNode!,next=el.nextSibling;el.remove();parent.insertBefore(el,next);});await expect(box(page)).toHaveText('After IME');
});
test('mobile contextual docking stays in viewport across themes; accessibility baseline',async({page})=>{
 await page.setViewportSize({width:390,height:844});await load(page);await select(page,'Mobile selection');await expect(contextual(page).locator('.base')).toHaveAttribute('data-placement','docked');
 const theme=page.getByRole('combobox',{name:'Inspired theme'});
 for(const value of ['holotable-inspired','shadcn-inspired','astryx-inspired','fluent-inspired','spectrum-inspired']){
  await theme.selectOption(value);await expect(page.getByRole('status',{name:'Theme result'})).not.toBeEmpty();await box(page).focus();await select(page,'Mobile selection');
  const bounds=await contextual(page).locator('.base').boundingBox();expect(bounds!.x).toBeGreaterThanOrEqual(0);expect(bounds!.x+bounds!.width).toBeLessThanOrEqual(391);
 }
 await page.locator('[data-rich-text-demo]').screenshot({path:test.info().outputPath(`en-rich-mobile-${test.info().project.name}.png`)});
 expect((await new AxeBuilder({page}).include('[data-rich-text-demo]').withTags(['wcag2a','wcag2aa','wcag21aa']).analyze()).violations).toEqual([]);
});
test('lists and multi-paragraph selection format without losing semantic content',async({page})=>{
 await load(page);await select(page,'First\nSecond');await box(page).press('ControlOrMeta+a');await bar(page).getByRole('button',{name:'Bullet list'}).click();await expect(host(page).locator('ul li')).toHaveCount(2);await expect(host(page)).toHaveJSProperty('value','First\nSecond');
 await bar(page).getByRole('button',{name:'Undo',exact:true}).click();await expect(host(page).locator('ul')).toHaveCount(0);
});
test('interactive tokens reopen by keyboard and adjacent deletion; Escape retains literal trigger text',async({page})=>{
 await load(page);await host(page).evaluate((el:any)=>{el.value='';el.focus();});await box(page).pressSequentially('@Cov');await box(page).press('Enter');
 const token=host(page).getByRole('button',{name:'Cover study',exact:true});await token.focus();await token.press('Enter');await expect(host(page).getByRole('listbox',{name:'Project references'})).toBeVisible();await box(page).press('Escape');await expect(host(page).getByRole('listbox')).not.toBeVisible();
 await host(page).evaluate((el:any)=>{el.value='';el.focus();});await box(page).pressSequentially('@Al');await box(page).press('Escape');await expect(host(page)).toHaveJSProperty('value','@Al');await expect(host(page).getByRole('listbox')).not.toBeVisible();
});
test('contextual Escape stays dismissed, stale link target closes, declaration retargets between backends',async({page})=>{
 await load(page);await select(page);await contextual(page).getByRole('button',{name:'Bold',exact:true}).focus();await page.keyboard.press('Escape');await expect(box(page)).toBeFocused();await expect(contextual(page).locator('.base')).not.toBeVisible();
 await bar(page).getByRole('button',{name:'Link',exact:true}).click();await expect(bar(page).getByRole('textbox',{name:'Link URL'})).toBeVisible();await host(page).evaluate((el:any)=>el.value='New draft');await expect(bar(page).getByRole('textbox',{name:'Link URL'})).not.toBeVisible();
 await page.evaluate(async()=>{
  // The same registered definition is already loaded by the existing token-editor examples.
  const trigger=document.createElement('en-editor-trigger') as any;
  trigger.id='shared-trigger';trigger.for='rich-brief';trigger.extension={id:'declared',trigger:'!',label:'Declared provider',provide:()=>[{id:'choice',label:'Shared choice',insert:[{kind:'text',text:'shared'}]}]};document.querySelector('[data-rich-text-demo]')!.append(trigger);
 });
 // Explicitly load the public definition through the example's registration closure.
 await expect(page.locator('#shared-trigger')).toHaveJSProperty('hasUpdated',true);
 await host(page).evaluate((el:any)=>{el.value='';el.focus();});await box(page).pressSequentially('!');await expect(host(page).getByRole('option',{name:'Shared choice'})).toBeVisible();
 await page.locator('#shared-trigger').evaluate((el:any)=>el.for='plain-reply');await expect(host(page).getByRole('listbox')).not.toBeVisible();
 const comparison=page.locator('#plain-reply');await comparison.evaluate((el:any)=>{el.value='';el.focus();});await comparison.getByRole('textbox').pressSequentially('!');await expect(comparison.getByRole('option',{name:'Shared choice'})).toBeVisible();
});
test('external paste sanitizes supported formatting and formatted-token history uses one transaction stream',async({page})=>{
 await load(page);await select(page,'Emphasis');await bar(page).getByRole('button',{name:'Italic',exact:true}).click();await box(page).press('ArrowRight');await box(page).pressSequentially(' @Cov');await box(page).press('Enter');await expect(host(page).locator('[data-token]')).toHaveCount(1);
 await bar(page).getByRole('button',{name:'Undo',exact:true}).click();await expect(host(page).locator('[data-token]')).toHaveCount(0);await expect(host(page).locator('em')).not.toHaveCount(0);
 await host(page).evaluate((el:any)=>{el.value='';el.focus();});await box(page).evaluate(el=>{const data=new DataTransfer();data.setData('text/plain','Safe text');data.setData('text/html','<img src=x onerror=alert(1)><b>Injected</b>');const event=new Event('paste',{bubbles:true,cancelable:true,composed:true});Object.defineProperty(event,'clipboardData',{value:data});el.dispatchEvent(event);});await expect(host(page)).toHaveJSProperty('value','Injected');await expect(host(page).locator('img')).toHaveCount(0);await expect(host(page).locator('strong')).toHaveText('Injected');
});

test('contextual link editing dismisses on outside interaction or cleared selection without restoring it',async({page})=>{
 await load(page);
 for(const placement of ['floating','docked']){
  await contextual(page).evaluate((el:any,placement)=>el.placement=placement,placement);
  await select(page);await contextual(page).getByRole('button',{name:'Link',exact:true}).click();
  await contextual(page).getByRole('textbox',{name:'Link URL'}).fill('https://example.com/cancelled');
  // Non-focusable content must dismiss even when the browser retains input focus.
  await page.getByRole('heading',{name:'Project brief',exact:true}).click();
  await expect(contextual(page).locator('.base')).not.toBeVisible();
  await expect(host(page).locator('a')).toHaveCount(0);
  await select(page,'Fresh selection');
  await expect(contextual(page).getByRole('textbox',{name:'Link URL'})).toHaveCount(0);
  await contextual(page).getByRole('button',{name:'Link',exact:true}).click();
  await box(page).click();
  await expect(contextual(page).locator('.base')).not.toBeVisible();
  await expect(host(page)).toHaveJSProperty('hasSelection',false);
  await expect(box(page)).toBeFocused();
  await select(page,'Keyboard selection');await contextual(page).getByRole('button',{name:'Link',exact:true}).click();
  await box(page).press('ArrowRight');
  await expect(contextual(page).locator('.base')).not.toBeVisible();
  await expect(host(page)).toHaveJSProperty('hasSelection',false);
  await select(page,'Leave the toolbar');await contextual(page).getByRole('button',{name:'Link',exact:true}).click();
  await page.getByRole('button',{name:'Reset brief',exact:true}).focus();
  await expect(contextual(page).locator('.base')).not.toBeVisible();
  // Using the URL field and Apply must retain the editor bookmark.
  await select(page,'Apply this link');await contextual(page).getByRole('button',{name:'Link',exact:true}).click();
  await contextual(page).getByRole('textbox',{name:'Link URL'}).fill('https://example.com/applied');
  await contextual(page).getByRole('button',{name:'Apply link'}).click();
  await expect(host(page).locator('a')).toHaveText('Apply this link');
  await expect(host(page).locator('a')).toHaveAttribute('href','https://example.com/applied');
 }
});

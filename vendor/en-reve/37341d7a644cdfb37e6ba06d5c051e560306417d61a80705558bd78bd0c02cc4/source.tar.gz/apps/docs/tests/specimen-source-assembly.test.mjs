import { test } from 'node:test';
import assert from 'node:assert/strict';
import { inlineSpecimenModules, specimenSources, usedImports } from '../scripts/specimen-sources.mjs';

test('copied modules inline nested helpers once and preserve public imports and TypeScript', () => {
  const result = inlineSpecimenModules("import './registration.js';\nimport { html } from 'lit';\nimport { helper } from './helper.js';\nexport const view = html`${helper('ok')}`;", {
    './registration.js': "import { html } from 'lit';\nimport { helper } from './helper.js';\ncustomElements.define('sample-view', class extends HTMLElement { render() { return html`${helper('registered')}`; } });",
    './helper.js': 'export function helper(value: string): string { return value; }',
  });
  assert.equal((result.match(/function helper/g) ?? []).length, 1);
  assert.equal((result.match(/import \{ html \}/g) ?? []).length, 1);
  assert.match(result, /value: string/);
  assert.doesNotMatch(result, /from '\.\//);
  assert.match(result, /customElements.define/);
});

test('conflicting same-name public imports fail instead of changing binding meaning', () => {
  assert.throws(() => inlineSpecimenModules("import { value } from 'one';\nimport './helper.js';", {
    './helper.js': "import { value } from 'two';\nconsole.log(value);",
  }), /Conflicting specimen import: value/);
});

test('only color specimens include the color registration; unrelated side effects remain', () => {
  const authored = "import './color-spaces-demo.js';\nimport './required-side-effect.js';\nimport { html } from 'lit';\n// example-start:button\nexport const button = html`<en-button>Go</en-button>`;\n// example-end:button\n// example-start:color-picker\nexport const picker = html`<en-color-spaces-demo></en-color-spaces-demo>`;\n// example-end:color-picker";
  const sources = specimenSources(authored, '', ...Array(11).fill(undefined), {
    './color-spaces-demo.js': "customElements.define('en-color-spaces-demo', class extends HTMLElement {});",
  });
  assert.doesNotMatch(sources.button, /color-spaces/);
  assert.match(sources.button, /required-side-effect/);
  assert.match(sources['color-picker'], /customElements.define/);
  assert.doesNotMatch(sources['color-picker'], /import '\.\/color-spaces/);
  assert.equal(usedImports("import './required.js';", 'sample.ts'), "import './required.js';");
});

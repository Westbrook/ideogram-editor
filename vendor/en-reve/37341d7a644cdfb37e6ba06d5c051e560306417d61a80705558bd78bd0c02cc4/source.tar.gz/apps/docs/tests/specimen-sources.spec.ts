import { preparedPackages, type PreparedArchive } from '../../../tooling/evidence/packed-setup.mjs';
import { setupEnvironment, setupEnvironmentInputs } from '../../../tooling/evidence/setup-environment.mjs';
import { immutableSetup } from '../../../tooling/evidence/immutable-setup.mjs';
import { contentInventory, inventoryDigest } from '../../../tooling/evidence/setup.mjs';
import { expect, test, type Page, type TestInfo } from '@playwright/test';
import { execFileSync } from 'node:child_process';
import { cp, mkdir, readFile, readdir, symlink, writeFile } from 'node:fs/promises';
import { createServer } from 'node:http';
import type { AddressInfo } from 'node:net';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

test('displayed examples compile without unused code, retain highlighting, and load encapsulated components and native styles without a bundler', async ({ page }, testInfo) => {
	test.setTimeout(60_000);
	const errors: string[] = [];
	page.on('pageerror', error => errors.push(error.message));
	await page.goto('/?progress-report#navigation');
	await expect(page.locator('en-sticker-app')).not.toHaveAttribute('data-ssr');
	for (const id of ['native-navigation', 'breadcrumbs', 'rhythm', 'split-view-vertical', 'command-surfaces']) {
		const disclosure = page.locator(`[data-specimen="${id}"] details`);
		const summary = disclosure.locator('summary');
		await summary.focus();
		await summary.press('Enter');
		await expect(disclosure).toHaveAttribute('open', '');
		await expect(disclosure).toHaveAttribute('data-highlighted', 'true');
		const code = disclosure.locator('pre > code');
		await expect(code).toBeVisible();
		expect(await code.evaluate(element => [...CSS.highlights.values()].some(highlight =>
			[...highlight].some(range => element.contains(range.startContainer))))).toBe(true);
		await summary.press('Enter');
	}
	// Compile the actual text a reader copies, including the maintained copy helper.
	// The compiler detects both missing dependencies and unused local bindings.
	const samples = await page.locator('[data-specimen]').evaluateAll(elements => elements.map(element => ({
		id: element.getAttribute('data-specimen')!,
		source: element.querySelector(':scope > .specimen-tools > .code-disclosure > pre > code')!.textContent!,
	})));
	const compilerEnvironment = () => setupEnvironment();
	const archiveDirectory = testInfo.outputPath('native-package-archives');
	await mkdir(archiveDirectory, { recursive: true });
	const archives = await preparedPackages(['tokens', 'styles', 'primitives', 'elements'], archiveDirectory);
	const archiveIdentity = archives.map(({ name, integrity, shasum, setup }) => ({ name, integrity, shasum, setupKey: setup.key }));
	const identity = async () => ({ samples, archives: archiveIdentity, runtime: process.version, platform: process.platform, arch: process.arch,
		environment: inventoryDigest(setupEnvironmentInputs(compilerEnvironment())),
		files: await contentInventory(repository, ['packages', 'node_modules', 'dist/styles/typography.css', 'apps/docs/tests/specimen-sources.spec.ts', 'tooling/evidence', process.execPath], (name: string) => /(^|\/)(\.cache|\.vite|artifacts|results|test-results)(\/|$)/.test(name) || name.endsWith('.tsbuildinfo')) });
	const inputs = await identity();
	const prepared = await immutableSetup({ cache: join(repository, 'node_modules/.cache/specimen-consumers'), inputs, verifyInputs: identity,
		produce: async (output: string) => {
	await mkdir(output, { recursive: true });
	await symlink(fileURLToPath(new URL('../../../node_modules', import.meta.url)), join(output, 'node_modules'), 'dir');
	await Promise.all(samples.map(sample => writeFile(join(output, `${sample.id}.ts`), sample.source)));
	await writeFile(join(output, 'package.json'), JSON.stringify({ type: 'module' }));
	await writeFile(join(output, 'tsconfig.json'), JSON.stringify({ compilerOptions: {
		target: 'ES2022', module: 'NodeNext', moduleResolution: 'NodeNext',
		lib: ['ES2022', 'DOM', 'DOM.Iterable'], types: [], strict: true,
		outDir: './public/samples', noUnusedLocals: true, noUnusedParameters: true,
		noUncheckedSideEffectImports: true,
		verbatimModuleSyntax: true, skipLibCheck: true,
	}, include: ['*.ts'] }));
	execFileSync(process.execPath, [fileURLToPath(new URL('../../../node_modules/typescript/bin/tsc', import.meta.url)),
		'-p', join(output, 'tsconfig.json'), '--pretty', 'false'], { encoding: 'utf8', timeout: 15_000, env: compilerEnvironment() });
			await prepareNativeConsumption(output, archives, archiveDirectory);
		},
	});
	const output = prepared.directory;
	await testInfo.attach('preparation-identity', { body: JSON.stringify({ key: prepared.key, reused: prepared.reused, originatingProducer: prepared.originatingProducer, extractedSamplesDigest: inventoryDigest(samples), archives }), contentType: 'application/json' });
	await testInfo.attach('compiled-examples', { body: JSON.stringify({ count: samples.length, ids: samples.map(sample => sample.id) }), contentType: 'application/json' });
	expect(errors).toEqual([]);
	await verifyNativeConsumption(page, output, testInfo);
});

const repository = fileURLToPath(new URL('../../../', import.meta.url));

async function filesBelow(directory: string, prefix = ''): Promise<string[]> {
	const files: string[] = [];
	for (const entry of await readdir(directory, { withFileTypes: true })) {
		const name = `${prefix}${entry.name}`;
		if (entry.isDirectory()) files.push(...await filesBelow(join(directory, entry.name), `${name}/`));
		else if (entry.isFile()) files.push(`./${name}`);
	}
	return files;
}

function browserTarget(value: unknown): string | undefined {
	if (typeof value === 'string') return value;
	if (Array.isArray(value)) return value.map(browserTarget).find(Boolean);
	if (!value || typeof value !== 'object') return undefined;
	for (const condition of ['browser', 'import', 'default']) {
		const target = browserTarget((value as Record<string, unknown>)[condition]);
		if (target) return target;
	}
	return undefined;
}

// Resolve only the packages' published browser exports. The native server never
// rewrites imports, transforms JS/CSS, or aliases a source TypeScript directory.
async function mapPackage(directory: string, urlRoot: string, imports: Record<string, string>) {
	const manifest = JSON.parse(await readFile(join(directory, 'package.json'), 'utf8'));
	const entries: Record<string, unknown> = manifest.exports && typeof manifest.exports === 'object'
		&& Object.keys(manifest.exports).some(key => key.startsWith('.'))
		? manifest.exports : { '.': manifest.exports ?? manifest.module ?? manifest.main };
	const files = await filesBelow(directory);
	for (const [key, conditions] of Object.entries(entries)) {
		const target = browserTarget(conditions);
		if (!target) continue;
		const normalized = target.startsWith('./') ? target : `./${target}`;
		const star = normalized.indexOf('*');
		if (star === -1) {
			expect(files, `${manifest.name} ${key} exists in the built package`).toContain(normalized);
			imports[key === '.' ? manifest.name : `${manifest.name}/${key.slice(2)}`] = `${urlRoot}${normalized.slice(2)}`;
		} else {
			const prefix = normalized.slice(0, star);
			const suffix = normalized.slice(star + 1);
			for (const file of files) {
				if (!file.startsWith(prefix) || !file.endsWith(suffix)) continue;
				const match = file.slice(prefix.length, suffix.length ? -suffix.length : undefined);
				imports[`${manifest.name}/${key.slice(2).replace('*', match)}`] = `${urlRoot}${file.slice(2)}`;
			}
		}
	}
}

async function prepareNativeConsumption(output: string, archives: PreparedArchive[], archiveDirectory: string) {
	const publicRoot = join(output, 'public');
	const imports: Record<string, string> = {};
	for (const name of ['tokens', 'styles', 'primitives', 'elements']) {
		const archive = archives.find(item => item.name === `@en-reve/${name}`);
		if (!archive) throw new Error(`Missing prepared archive: ${name}`);
		const destination = join(publicRoot, 'packages', name);
		await mkdir(destination, { recursive: true });
		execFileSync('tar', ['-xzf', join(archiveDirectory, archive.filename), '-C', destination, '--strip-components=1'], { encoding: 'utf8', env: setupEnvironment(process.env, { production: false }) });
		await mapPackage(destination, `/packages/${name}/`, imports);
	}
	for (const name of ['lit', 'lit-html', 'lit-element', '@lit/reactive-element', 'signal-polyfill', 'signal-utils']) {
		const destination = join(publicRoot, 'vendor', name);
		await cp(join(repository, 'node_modules', name), destination, { recursive: true, dereference: true });
		await mapPackage(destination, `/vendor/${name}/`, imports);
	}
	await mkdir(join(publicRoot, 'styles'), { recursive: true });
	for (const name of ['typography']) {
		await cp(join(repository, 'dist', 'styles', `${name}.css`), join(publicRoot, 'styles', `${name}.css`));
	}
	await writeFile(join(publicRoot, 'index.html'), `<!doctype html><html lang="en"><head>
		<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
		<title>Native specimen consumer</title><link rel="icon" href="data:,">
		<link rel="stylesheet" href="${imports['@en-reve/tokens/default.css']}">
		<script type="importmap">${JSON.stringify({ imports })}</script>
		<script type="module" src="/bootstrap.js"></script>
		</head><body><main id="sample"></main><section id="fields">Fields destination</section>
		<section id="sheet">Sticker sheet destination</section></body></html>`);
	await writeFile(join(publicRoot, 'bootstrap.js'), `
		import { render } from 'lit';
		const examples = {
			'native-navigation': { name: 'nativeNavigationExample', elements: ['navigation'] },
			breadcrumbs: { name: 'breadcrumbsExample', elements: ['breadcrumbs'] },
			typography: { name: 'typographyExample', elements: ['stack'] },
			card: { name: 'cardExample', elements: ['card', 'stack', 'avatar', 'badge', 'button'] },
			combobox: { name: 'comboboxExample', elements: ['combobox', 'select', 'button'] },
			'command-surfaces': { name: 'commandSurfacesExample', elements: ['stack', 'button', 'toolbar', 'menu', 'menu-item', 'command-palette'] },
		};
		const id = new URL(location.href).searchParams.get('sample');
		const example = examples[id];
		if (!example) throw new Error('Unknown example: ' + id);
		await Promise.all(example.elements.map(name => import('@en-reve/elements/define/' + name + '.js')));
		const source = await import('/samples/' + id + '.js');
		render(source[example.name](), document.querySelector('#sample'));
		await Promise.all([...document.querySelectorAll('*')].map(element => element.updateComplete));
		document.body.dataset.ready = id;
	`);

}
async function verifyNativeConsumption(page: Page, output: string, testInfo: TestInfo) {
	const publicRoot = join(output, 'public');

	const server = createServer(async (request, response) => {
		try {
			const pathname = decodeURIComponent(new URL(request.url ?? '/', 'http://localhost').pathname);
			const path = resolve(publicRoot, `.${pathname === '/' ? '/index.html' : pathname}`);
			if (!path.startsWith(publicRoot + sep)) throw new Error('Outside fixture');
			const body = await readFile(path);
			const types: Record<string, string> = {
				'.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
				'.css': 'text/css; charset=utf-8', '.json': 'application/json',
			};
			response.writeHead(200, { 'Content-Type': types[extname(path)] ?? 'application/octet-stream', 'Cache-Control': 'no-store' });
			response.end(body);
		} catch {
			response.writeHead(404);
			response.end('Not found');
		}
	});
	await new Promise<void>((resolve, reject) => {
		server.once('error', reject);
		server.listen(0, '127.0.0.1', resolve);
	});
	const baseURL = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
	const errors: string[] = [];
	const stylesheets: string[] = [];
	page.on('pageerror', error => errors.push(error.message));
	page.on('requestfailed', request => errors.push(`${request.method()} ${request.url()}: ${request.failure()?.errorText}`));
	page.on('response', response => {
		if (!response.ok()) errors.push(`${response.status()} ${response.url()}`);
		if (response.request().resourceType() === 'stylesheet') {
			if (!response.headers()['content-type']?.includes('text/css')) errors.push(`Incorrect stylesheet MIME type: ${response.url()}`);
			stylesheets.push(new URL(response.url()).pathname);
		}
	});
	const evidence: { id: string; stylesheets: string[] }[] = [];
	try {
		for (const id of ['native-navigation', 'breadcrumbs', 'typography', 'card', 'combobox', 'command-surfaces']) {
			stylesheets.length = 0;
			await page.goto(`${baseURL}/?sample=${id}`);
			await expect(page.locator('body')).toHaveAttribute('data-ready', id);
			if (id === 'typography' || id === 'card') {
				await expect.poll(() => stylesheets).toContain('/styles/typography.css');
			} else {
				await expect(page.locator('link[href="/styles/navigation.css"]')).toHaveCount(0);
			}
			if (id === 'native-navigation') {
				const host = page.locator('en-navigation');
				const navigation = host.getByRole('navigation', { name: 'Explore related patterns' });
				expect(await host.evaluate(element => !!element.shadowRoot?.querySelector('nav'))).toBe(true);
				expect(await navigation.evaluate(element => element.localName)).toBe('nav');
				await expect(navigation).toHaveCSS('position', 'static');
				await expect(navigation).toHaveCSS('display', 'flex');
				await expect(navigation).toHaveCSS('flex-wrap', 'wrap');
				const link = host.getByRole('link', { name: 'Fields', exact: true });
				expect(await link.evaluate(element => element.localName)).toBe('a');
				await expect(host.locator(':scope > a')).toHaveCount(3);
				expect(await host.evaluate(element => element.shadowRoot!.querySelectorAll('a').length)).toBe(0);
				// A flex item's inline outer display is blockified by its parent.
				await expect(link).toHaveCSS('display', 'block');
				await link.focus();
				await link.press('Enter');
				await expect(page).toHaveURL(`${baseURL}/?sample=${id}#fields`);
			} else if (id === 'breadcrumbs') {
				const host = page.locator('en-breadcrumbs');
				const navigation = host.getByRole('navigation', { name: 'Pattern location' });
				expect(await host.evaluate(element => !!element.shadowRoot?.querySelector('nav'))).toBe(true);
				expect(await navigation.evaluate(element => element.localName)).toBe('nav');
				expect(await navigation.getByRole('list').evaluate(element => element.localName)).toBe('ol');
				await expect(navigation.getByRole('list')).toHaveCSS('display', 'flex');
				await expect(navigation.getByRole('list')).toHaveCSS('list-style-type', 'none');
				await expect(host.locator(':scope > [aria-current="location"]')).toHaveText('Navigation patterns');
				expect(await host.evaluate(element => element.shadowRoot!.slotAssignment)).toBe('manual');
				await expect(host.locator(':scope > a')).toHaveAttribute('href', '#sheet');
				await host.getByRole('link', { name: 'Sticker sheet' }).click();
				await expect(page).toHaveURL(`${baseURL}/?sample=${id}#sheet`);
			} else if (id === 'typography') {
				await expect(page.locator('.en-heading-large')).toHaveCSS('margin-block-start', '0px');
				await expect(page.locator('.en-heading-large')).toHaveCSS('font-size', '32px');
				await expect(page.locator('.en-body')).toHaveCSS('line-height', '24px');
				expect(await page.locator('en-stack').evaluate(element => !!element.shadowRoot)).toBe(true);
			} else if (id === 'command-surfaces') {
				// Exercise the exact compiled copy through public hosts and native interaction.
				// This consumer has no docs Reset control, example controller or bundler.
				const toolbar = page.locator('#specimen-toolbar');
				const menu = page.locator('#specimen-menu');
				const palette = page.locator('#specimen-command-palette');
				const result = page.locator('[data-command-result]');
				const preview = page.locator('[data-command-preview]');
				expect(await page.evaluate(() =>
					['stack', 'button', 'toolbar', 'menu', 'menu-item', 'command-palette']
						.every(name => Boolean(customElements.get(`en-${name}`))))).toBe(true);
				expect(await page.evaluate(() => customElements.get('en-select') === undefined)).toBe(true);
				await expect(result).toHaveText('Preview layout: Portrait.');
				await expect(toolbar.getByRole('toolbar', { name: 'Study layout actions', exact: true })).toBeVisible();
				// Authored buttons are light-DOM children, so locate them from the host.
				const portrait = toolbar.getByRole('button', { name: 'Portrait', exact: true });
				const landscape = toolbar.getByRole('button', { name: 'Landscape', exact: true });
				await portrait.focus();
				await portrait.press('ArrowRight');
				await expect(landscape).toBeFocused();
				await expect(result).toHaveText('Preview layout: Portrait.');
				await landscape.press('Enter');
				await expect(result).toHaveText('Preview layout: Landscape.');
				await expect(preview).toHaveAttribute('data-layout', 'landscape');

				const menuTrigger = page.getByRole('button', { name: 'More layout actions', exact: true });
				await menuTrigger.click();
				await expect(menu.getByRole('menu', { name: 'Study layout actions', exact: true })).toBeVisible();
				await expect(menu.getByRole('menuitem', { name: 'Publish study', exact: true })).toHaveAttribute('aria-disabled', 'true');
				await menu.getByRole('menuitem', { name: 'Portrait', exact: true }).click();
				await expect(menu).toHaveJSProperty('open', false);
				await expect(result).toHaveText('Preview layout: Portrait.');
				await expect(preview).toHaveAttribute('data-layout', 'portrait');
				await expect(menuTrigger).toBeFocused();

				const searchTrigger = page.getByRole('button', { name: 'Search layout commands', exact: true });
				const dialog = palette.getByRole('dialog', { name: 'Study commands', exact: true });
				const search = palette.getByRole('combobox', { name: 'Find a layout command', exact: true });
				await searchTrigger.click();
				await expect(dialog).toBeVisible();
				await expect(search).toBeFocused();
				await search.fill('publish');
				await expect(palette.getByRole('option', { name: 'Publish study', exact: true })).toHaveAttribute('aria-disabled', 'true');
				await search.press('Enter');
				await expect(dialog).toBeVisible();
				await expect(result).toHaveText('Preview layout: Portrait.');
				await search.fill('not-a-layout');
				await expect(palette.getByText('No matching layout commands.', { exact: true })).toBeVisible();
				await expect(palette.getByRole('option')).toHaveCount(0);
				await search.press('Escape');
				await expect(palette).toHaveJSProperty('open', false);
				await expect(searchTrigger).toBeFocused();
				await expect(result).toHaveText('Preview layout: Portrait.');
				await searchTrigger.click();
				await search.fill('wide');
				await palette.getByRole('option', { name: 'Landscape', exact: true }).click();
				await expect(palette).toHaveJSProperty('open', false);
				await expect(result).toHaveText('Preview layout: Landscape.');
				await expect(preview).toHaveAttribute('data-layout', 'landscape');
				await expect(searchTrigger).toBeFocused();
			} else if (id === 'combobox') {
				const input = page.getByRole('combobox', { name: 'Project', exact: true });
				await input.fill('South');
				await input.press('ArrowDown');
				await expect(input).toHaveAttribute('aria-expanded', 'true');
				await expect(page.getByRole('option', { name: 'Studio South', exact: true })).toBeVisible();
				await input.press('Enter');
				await expect(input).toHaveValue('Studio South');
				await page.getByRole('button', { name: 'Use project', exact: true }).click();
				await expect(page.locator('output')).toHaveText('Submitted project: studio-south');
			} else {
				await expect(page.locator('.en-metadata')).toHaveCSS('margin-block-start', '0px');
				await expect(page.locator('.en-metadata')).toHaveCSS('font-size', '13px');
				await expect(page.getByRole('button', { name: 'Open study' })).toBeVisible();
				expect(await page.locator('en-card').evaluate(element => !!element.shadowRoot)).toBe(true);
			}
			if (id === 'native-navigation' || id === 'breadcrumbs') expect(stylesheets).not.toContain('/styles/navigation.css');
			evidence.push({ id, stylesheets: [...stylesheets] });
		}
		expect(errors).toEqual([]);
		await testInfo.attach('native-consumption', { body: JSON.stringify({ bundler: false, examples: evidence }), contentType: 'application/json' });
	} finally {
		await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
	}
}

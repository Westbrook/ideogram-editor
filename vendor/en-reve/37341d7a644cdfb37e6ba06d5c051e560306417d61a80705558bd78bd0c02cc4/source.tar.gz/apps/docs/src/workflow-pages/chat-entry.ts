import { startWorkflowPage } from '../workflows-client.js';
import '@en-reve/elements/define/presence-group.js';
import '@en-reve/elements/define/activity-feed.js';
import '@en-reve/elements/define/skeleton.js';
import '@en-reve/elements/define/chat-message.js';
import '@en-reve/elements/define/chat-composer.js';
import '@en-reve/elements/define/card.js';
import '@en-reve/elements/define/textarea.js';
import '@en-reve/elements/define/slider.js';
import { ChatWorkflowApp } from './chat.js';

await startWorkflowPage(ChatWorkflowApp);

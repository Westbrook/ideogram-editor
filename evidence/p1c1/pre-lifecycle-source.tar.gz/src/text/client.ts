import { frozen, LIMITS, TextFailure } from './contracts';
import type { PreparedText, TextRequest } from './contracts';
import { engineReservationBytes, engineResidentBytes, planText, retainPrepared, textMemory, unownedFontBytes } from './memory';
import type { Reservation, TextPlan } from './memory';
export { releasePrepared, textMemory } from './memory';
export type { PreparedText, TextRequest, TextToken, TextStyle, FontInput } from './contracts';

// Healthy workers are reused: the whole native heap remains booked while idle.
// HTML exposes no worker-close event to application code. Terminated workers and
// cancelled jobs therefore keep their reservations until this realm is destroyed.
// A host/test close event is evidence for storage cleanup, not a runtime refund.
export class TextRenderer {
  #serial = 0;
  #disposed = false;
  #worker?: Worker;
  #ready = false;
  #engineLease?: Reservation;
  #active?: { serial: number; reject: (error: Error) => void; timer: ReturnType<typeof setTimeout>; lease: Reservation };
  #terminations = 0;
  #quarantined = 0;
  #terminate() {
    if (!this.#worker) return;
    this.#worker.onmessage = null; this.#worker.onerror = null;
    this.#worker.terminate(); this.#worker = undefined; this.#ready = false; this.#terminations++;
    this.#quarantined += this.#engineLease!.bytes; this.#engineLease = undefined;
  }
  #stop(code: string) {
    const active = this.#active; if (!active) return;
    this.#active = undefined; clearTimeout(active.timer);
    this.#quarantined += active.lease.bytes; this.#terminate();
    active.reject(new TextFailure(code));
  }
  cancel() { this.#serial++; this.#stop('TEXT_CANCELLED'); }
  dispose() { this.#disposed = true; this.cancel(); this.#terminate(); }
  get lifecycle() { return Object.freeze({ activeWorkers: this.#active ? 1 : 0, idleWorkers: this.#worker && !this.#active ? 1 : 0,
    terminations: this.#terminations, disposed: this.#disposed, quarantinedBytes: this.#quarantined }); }
  async prepare(input: TextRequest): Promise<PreparedText> {
    if (this.#disposed) throw new TextFailure('TEXT_DISPOSED');
    const plan = planText(input); // scans only; no index arrays/clone/native work
    this.#stop('TEXT_STALE'); const serial = ++this.#serial;
    textMemory.check(plan.bytes + (this.#worker ? 0 : engineResidentBytes));
    let newEngine: Reservation | undefined, lease: Reservation;
    try {
      if (!this.#worker) newEngine = textMemory.reserve(engineReservationBytes);
      lease = textMemory.reserve(this.#ready ? plan.bytes : plan.startup);
    } catch (error) { newEngine?.release(); throw error; }
    let request: TextRequest;
    try {
      // Snapshot small metadata while retaining the same immutable Blob handles;
      // postMessage below is the only structured-clone boundary for font bytes.
      const t = input.token, s = input.style;
      request = { text: input.text, token: { documentId: t.documentId, documentRevision: t.documentRevision,
        layerId: t.layerId, layerVersion: t.layerVersion, sessionId: t.sessionId, generation: t.generation },
        frame: { width: input.frame.width, height: input.frame.height },
        style: { primaryFont: s.primaryFont, explicitFallbacks: [...s.explicitFallbacks], sizePx: s.sizePx,
          lineHeightMultiplier: s.lineHeightMultiplier, fill: [...s.fill], align: s.align, direction: s.direction },
        fonts: input.fonts.map(f => ({ hash: f.hash, bytes: f.bytes, faceIndex: f.faceIndex, origin: f.origin,
          license: { hash: f.license.hash, embedding: f.license.embedding } })) };
      if (!this.#worker) {
        this.#worker = new Worker(new URL('./worker.ts', import.meta.url), { type: 'module', name: 'ideogram-text-' + serial });
        this.#engineLease = newEngine;
      }
    } catch (error) { lease.release(); newEngine?.release(); throw error; }
    const worker = this.#worker;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => this.#stop('TEXT_DEADLINE'), LIMITS.deadlineMs);
      this.#active = { serial, reject, timer, lease };
      worker.onerror = event => { event.preventDefault(); this.#stop('TEXT_WORKER_FAILURE'); };
      worker.onmessage = event => {
        if (this.#active?.serial !== serial || serial !== this.#serial) return;
        const message = event.data;
        if (message.ready) {
          this.#engineLease!.release(); this.#engineLease = textMemory.reserve(engineResidentBytes); this.#ready = true;
          lease.release();
          try { lease = textMemory.reserve(plan.bytes); this.#active.lease = lease; worker.postMessage(request); }
          catch (error) { clearTimeout(timer); this.#active = undefined; worker.onmessage = null; reject(error); }
          return;
        }
        this.#active = undefined; clearTimeout(timer);
        worker.onmessage = null; worker.onerror = null;
        if (message.fatal) { this.#quarantined += lease.bytes; this.#terminate(); }
        else lease.release();
        if (!message.ok) { reject(new TextFailure(message.code, message.details)); return; }
        const result = message.value as PreparedText;
        try {
          this.#validateResult(result, request, plan);
          // Original immutable input Blobs are the authoritative dependencies.
          // The returned clones are dropped; their peak was booked in the job.
          const value = { ...result, dependencies: result.dependencies.map(d => ({...d, bytes: request.fonts.find(f => f.hash === d.hash)!.bytes})) };
          retainPrepared(value, result.rgba.size + result.layout.size + result.textUtf8.size + unownedFontBytes(request));
          resolve(frozen(value));
        } catch (error) { reject(error); }
      };
      try { if (this.#ready) worker.postMessage(request); } catch { this.#stop('TEXT_WORKER_FAILURE'); }
    });
  }
  #validateResult(result: PreparedText, request: TextRequest, plan: TextPlan) {
    if (JSON.stringify(result.token) !== JSON.stringify(request.token)) throw new TextFailure('TEXT_STALE');
    if (!(result.rgba instanceof Blob) || result.rgba.size !== plan.raster || !(result.layout instanceof Blob) || result.layout.size > plan.layout ||
        !(result.textUtf8 instanceof Blob) || result.textUtf8.size > LIMITS.textBytes || result.dependencies.length !== request.fonts.length ||
        result.dependencies.some(d => !request.fonts.some(f => f.hash === d.hash && f.bytes.size === d.bytes.size))) throw new TextFailure('TEXT_RESULT_BUDGET');
  }
}

# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> pinned WASM allocator refuses growth above the explicit worker heap cap
- Location: tests/text/renderer.spec.ts:166:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 134217728
Received:   134217728
```

# Test source

```ts
  70  |     const empty=await draw({text:''}),wrap=await draw({frame:{width:40,height:300}}),rtl=await draw({text:'ABC',style:{...q.style,direction:'rtl'}});
  71  |     return{full,half,clipped,zero,empty,wrap,rtl};
  72  |   });
  73  |   const {full,half,clipped,zero,empty,wrap,rtl}=output;
  74  |   expect(full.overflow).toBe(false);expect(clipped.overflow).toBe(true);expect([clipped.width,clipped.height]).toEqual([120,21]);
  75  |   let opaque=0;
  76  |   for(let i=0;i<full.pixels.length;i+=4){
  77  |     if(full.pixels[i+3]===255){expect(full.pixels.slice(i,i+4)).toEqual([40,90,190,255]);expect(half.pixels.slice(i,i+4)).toEqual([40,90,190,128]);opaque++;}
  78  |     if(full.pixels[i+3]===0)expect(full.pixels.slice(i,i+4)).toEqual([0,0,0,0]);
  79  |   }
  80  |   expect(opaque).toBeGreaterThan(0);expect(zero.pixels.every((v:number)=>v===0)).toBe(true);expect(empty.pixels.every((v:number)=>v===0)).toBe(true);
  81  |   expect(empty.layout.paragraphs).toHaveLength(1);expect(wrap.layout.paragraphs[0].lines.length).toBeGreaterThan(1);
  82  |   expect(wrap.layout.logicalLines).toBe(2);expect(rtl.layout.paragraphs[0].direction).toBe('rtl');
  83  |   let fractional=false;
  84  |   for(let x=0;x<120;x++){const i=(20*120+x)*4;if(full.pixels[i+3]===255&&clipped.pixels[i+3]>0&&clipped.pixels[i+3]<255)fractional=true;}
  85  |   expect(fractional).toBe(true);
  86  |   await info.attach('pixel-controls',{body:JSON.stringify(Object.fromEntries(Object.entries(output).map(([k,v]:[string,any])=>[k,{...v,pixels:undefined}]))),contentType:'application/json'});
  87  | });
  88  | 
  89  | test('missing, corrupt, restricted, unreviewed and hash-mismatched fonts refuse preparation',async({page},info)=>{
  90  |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  91  |   const results=await page.evaluate(async()=>{
  92  |     const f=(window as any).textFixture, base=await f.request('ABC'), results:any={};
  93  |     async function check(key:string,q:any){try{await f.renderer.prepare(q);results[key]={accepted:true};}catch(e:any){results[key]={code:e.code,details:e.details};}}
  94  |     await check('missingGlyph',{...base,text:'𝄞'});
  95  |     await check('missingFont',{...base,fonts:[]});
  96  |     await check('hashMismatch',{...base,fonts:[{...base.fonts[0],bytes:new Blob(['bad'])}]});
  97  |     await check('unreviewed',{...base,fonts:[{...base.fonts[0],license:{hash:base.fonts[0].license.hash,embedding:'unknown'}}]});
  98  |     await check('faceIndex',{...base,fonts:[{...base.fonts[0],faceIndex:1}]});
  99  |     await check('unlistedFallback',{...base,style:{...base.style,explicitFallbacks:[base.fonts[0].hash]}});
  100 |     async function mutated(key:string,mutate:(b:ArrayBuffer)=>void){const b=await base.fonts[0].bytes.arrayBuffer();mutate(b);const bytes=new Blob([b]),hash=await f.hashBytes(bytes);await check(key,{...base,fonts:[{...base.fonts[0],bytes,hash}],style:{...base.style,primaryFont:hash}});}
  101 |     await mutated('corrupt',b=>new Uint8Array(b)[b.byteLength-12]^=1);
  102 |     await mutated('tableBounds',b=>new DataView(b).setUint32(20,b.byteLength+4));
  103 |     await mutated('restricted',b=>{
  104 |       const v=new DataView(b),u=new Uint8Array(b);
  105 |       for(let i=0;i<v.getUint16(4);i++){const at=12+i*16;if(String.fromCharCode(...u.slice(at,at+4))!=='OS/2')continue;
  106 |         const start=v.getUint32(at+8),length=v.getUint32(at+12);v.setUint16(start+8,2);let sum=0;
  107 |         for(let j=0;j<length;j+=4){let word=0;for(let k=0;k<4;k++)word=word*256+(j+k<length?u[start+j+k]:0);sum=(sum+word)>>>0;}v.setUint32(at+4,sum);
  108 |       }
  109 |     });
  110 |     return results;
  111 |   });
  112 |   expect(results.missingGlyph).toEqual({code:'TEXT_MISSING_GLYPHS',details:{codepoints:[0x1d11e]}});
  113 |   expect(results.missingFont.code).toBe('FONT_ORDER');expect(results.hashMismatch.code).toBe('FONT_HASH');
  114 |   expect(results.unreviewed.code).toBe('FONT_EMBEDDING_UNKNOWN');expect(results.faceIndex.code).toBe('FONT_FACE_INDEX');
  115 |   expect(results.unlistedFallback.code).toBe('FONT_ORDER');expect(results.corrupt.code).toBe('FONT_TABLE_CHECKSUM');
  116 |   expect(results.tableBounds.code).toBe('FONT_TABLE_BOUNDS');expect(results.restricted.code).toBe('FONT_EMBEDDING_RESTRICTED');
  117 |   await info.attach('refusals',{body:JSON.stringify(results),contentType:'application/json'});
  118 | });
  119 | 
  120 | test('exact admission boundaries preserve input and reject unsafe indices and geometry',async({page})=>{
  121 |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  122 |   const result=await page.evaluate(async()=>{
  123 |     const f=(window as any).textFixture,q=await f.request('a'),cases:any={};
  124 |     for(const [name,text] of Object.entries({bytesAt:'x'.repeat(16384),bytesOver:'x'.repeat(16385),utf8At:'é'.repeat(8192),utf8Over:'é'.repeat(8193),linesAt:'\n'.repeat(255),linesOver:'\n'.repeat(256),surrogate:'\ud800',crlf:'a\r\nb',combining:'A\u0301'})){
  125 |       try{const i=f.textIndices(text);cases[name]={bytes:i.bytes,lines:i.lines};}catch(e:any){cases[name]=e.code;}
  126 |     }
  127 |     for(const [name,frame] of Object.entries({zero:{width:0,height:1},infinite:{width:Infinity,height:1},pixelsOver:{width:5000,height:5001},pixelsAt:{width:5000,height:5000}})){
  128 |       try{f.admitRequest({...q,frame});cases[name]='accepted';}catch(e:any){cases[name]=e.code;}
  129 |     }
  130 |     const font=q.fonts[0];
  131 |     for(const [name,fonts] of Object.entries({faceOver:[{...font,bytes:new Blob([new Uint8Array(16777217)])}],facesOver:Array.from({length:17},(_,i)=>({...font,hash:'sha256:'+i.toString(16).padStart(64,'0')}))})){
  132 |       try{f.admitRequest({...q,fonts,style:{...q.style,primaryFont:fonts[0].hash,explicitFallbacks:fonts.slice(1).map((x:any)=>x.hash)}});cases[name]='accepted';}catch(e:any){cases[name]=e.code;}
  133 |     }
  134 |     cases.directions=['123 مرحبا','ABC مرحبا','\u2067مرحبا\u2069 ABC','123'].map(f.paragraphDirection);
  135 |     return cases;
  136 |   });
  137 |   expect(result.bytesAt.bytes).toBe(16384);expect(result.bytesOver).toBe('TEXT_BYTES');expect(result.utf8At.bytes).toBe(16384);expect(result.utf8Over).toBe('TEXT_BYTES');
  138 |   expect(result.linesAt.lines).toBe(256);expect(result.linesOver).toBe('TEXT_LINES');expect(result.surrogate).toBe('TEXT_SURROGATE');expect(result.crlf).toBe('TEXT_REQUIRES_REVIEWED_LF_CONVERSION');
  139 |   expect(result.combining.bytes).toBe(3);expect(result.pixelsAt).toBe('accepted');
  140 |   for(const k of ['zero','infinite','pixelsOver'])expect(result[k]).toBe('TEXT_FRAME');
  141 |   expect(result.faceOver).toBe('FONT_SIZE');expect(result.facesOver).toBe('FONT_ORDER');
  142 |   expect(result.directions).toEqual(['rtl','ltr','ltr','ltr']);
  143 | });
  144 | 
  145 | test('supersession, cancel and dispose terminate owned workers without publishing old generations',async({page},info)=>{
  146 |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  147 |   const workers:{url:string;closed:boolean}[]=[];
  148 |   page.on('worker',w=>{const entry={url:w.url(),closed:false};workers.push(entry);w.on('close',()=>entry.closed=true);});
  149 |   const result=await page.evaluate(async()=>{
  150 |     const f=(window as any).textFixture,q=await f.request('first');
  151 |     const first=f.renderer.prepare(q).then(()=> 'unexpected', (e:any)=>e.code);
  152 |     const second=f.renderer.prepare({...q,text:'second',token:{...q.token,generation:q.token.generation+1}});
  153 |     const current=await second,firstResult=await first;
  154 |     const cancelled=f.renderer.prepare(q).then(()=> 'unexpected',(e:any)=>e.code);f.renderer.cancel();
  155 |     const cancelResult=await cancelled;
  156 |     const disposed=f.renderer.prepare(q).then(()=> 'unexpected',(e:any)=>e.code);f.renderer.dispose();
  157 |     const disposeResult=await disposed;
  158 |     let after='';try{await f.renderer.prepare(q);}catch(e:any){after=e.code;}
  159 |     return{firstResult,cancelResult,disposeResult,after,text:await current.textUtf8.text(),generation:current.token.generation,lifecycle:f.renderer.lifecycle};
  160 |   });
  161 |   expect(result.firstResult).toBe('TEXT_STALE');expect(result.cancelResult).toBe('TEXT_CANCELLED');expect(result.disposeResult).toBe('TEXT_CANCELLED');expect(result.after).toBe('TEXT_DISPOSED');
  162 |   expect(result.text).toBe('second');expect(result.generation).toBe(2);expect(result.lifecycle).toEqual({activeWorkers:0,terminations:4,disposed:true});
  163 |   await info.attach('lifecycle',{body:JSON.stringify({result,workers,resetCalls:0,storage:'No origin storage written or reset by functional fixture.'}),contentType:'application/json'});
  164 | });
  165 | 
  166 | test('pinned WASM allocator refuses growth above the explicit worker heap cap',async({page},info)=>{
  167 |   const result=await page.evaluate(()=>(window as any).textFixture.heapControl());
  168 |   expect(result.error).toBeUndefined();expect(result.pointer).toBeGreaterThan(0);
  169 |   expect(result.overPointer).toBe(0);expect(result.final).toBeLessThanOrEqual(128*1024**2);
> 170 |   expect(result.after).toBeGreaterThan(result.before);
      |                        ^ Error: expect(received).toBeGreaterThan(expected)
  171 |   await info.attach('heap-admission',{body:JSON.stringify(result),contentType:'application/json'});
  172 | });
  173 | 
  174 | test('stock native storage reset requires observed closure of every actual text worker',async({playwright,browserName},info)=>{
  175 |   const profile=browserName==='webkit'?await mkdtemp(resolve(await realpath(tmpdir()),'ie-text-worker-')):undefined;
  176 |   const browser=profile?undefined:await playwright[browserName].launch();
  177 |   const context=profile?await playwright.webkit.launchPersistentContext(profile):await browser!.newContext();
  178 |   await Promise.all(context.pages().map(p=>p.close()));
  179 |   const storage=await ownedOPFS(context,profile??browserName+' ephemeral');
  180 |   const page=await context.newPage(),workers:{url:string;closed:boolean}[]=[],errors:string[]=[];
  181 |   page.on('pageerror',e=>errors.push(e.message));
  182 |   page.on('worker',w=>{const entry={url:w.url(),closed:false};workers.push(entry);w.on('close',()=>entry.closed=true);});
  183 |   let outcome='incomplete',error:string|null=null;
  184 |   const marker='text-worker-'+randomUUID();
  185 |   try{
  186 |     await storage.admit(page,origin);await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  187 |     await page.evaluate(async name=>{
  188 |       const root=await navigator.storage.getDirectory(),file=await root.getFileHandle(name,{create:true}),writer=await file.createWritable();
  189 |       await writer.write('Owned worker cleanup control');await writer.close();
  190 |       const f=(window as any).textFixture,q=await f.request('native worker cleanup');
  191 |       await f.renderer.prepare(q);
  192 |       try{await f.renderer.prepare({...q,text:'𝄞'});}catch(e:any){if(e.code!=='TEXT_MISSING_GLYPHS')throw e;}
  193 |     },marker);
  194 |     const workerStarted=page.waitForEvent('worker');
  195 |     await page.evaluate(async()=>{
  196 |       const f=(window as any).textFixture,q=await f.request('cancel real worker');
  197 |       (window as any).pendingText=f.renderer.prepare(q).catch((e:any)=>e.code);
  198 |     });
  199 |     await workerStarted;
  200 |     const cancellation=await page.evaluate(async()=>{
  201 |       const f=(window as any).textFixture;f.renderer.cancel();f.renderer.dispose();return await (window as any).pendingText;
  202 |     });
  203 |     expect(cancellation).toBe('TEXT_CANCELLED');
  204 |     expect(workers.length).toBeGreaterThan(0);
  205 |     try{await storage.cleanup();storage.verify();outcome='clean';}catch(e){error=String(e);}
  206 |     const reset=storage.ledger.filter((x:any)=>x.phase==='public-reset');
  207 |     if(outcome==='clean'){
  208 |       expect(workers.every(w=>w.closed)).toBe(true);expect(reset).toHaveLength(1);
  209 |       expect(storage.ledger.some((x:any)=>x.phase==='post-reset'&&x.entries.length===0)).toBe(true);
  210 |     }else{
  211 |       expect(reset).toHaveLength(0);
  212 |       expect(storage.ledger.some((x:any)=>x.phase==='cleanup-incomplete')).toBe(true);
  213 |       info.annotations.push({type:'cleanup-incomplete',description:error+'; no reset; owned marker absence unclaimed'});
  214 |     }
  215 |     expect(errors).toEqual([]);
  216 |   }finally{
  217 |     await info.attach('native-worker-cleanup',{body:JSON.stringify({browserName,origin,marker,outcome,error,workers,errors,ledger:storage.ledger},null,2),contentType:'application/json'});
  218 |     await context.close();await browser?.close();
  219 |     if(profile&&outcome==='clean')await rm(profile,{recursive:true});
  220 |   }
  221 | });
  222 | 
```
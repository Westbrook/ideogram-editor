# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker Latin, combining, ligature and supplementary mapping
- Location: tests/text/renderer.spec.ts:22:1

# Error details

```
Error: Use an owner-only storage directory with no symbolic links (0700 directories, 0600 files).
```

```
TypeError: Cannot read properties of undefined (reading 'close')
```

# Test source

```ts
  1   | import { test, expect } from '@playwright/test';
  2   | import { mkdtemp, rm } from 'node:fs/promises';
  3   | import { resolve } from 'node:path';
  4   | import { pathToFileURL } from 'node:url';
  5   | import { tmpdir } from 'node:os';
  6   | import { randomUUID } from 'node:crypto';
  7   | import { ownedOPFS } from '../editor/owned-opfs';
  8   | const {startLocalServer}=await import(pathToFileURL(resolve('dist/local/server/http.js')).href);
  9   | let server: Awaited<ReturnType<typeof startLocalServer>>, origin: string, root: string;
  10  | test.beforeAll(async () => {
  11  |   root=await mkdtemp(resolve(tmpdir(),'ie-text-host-'));
  12  |   server=await startLocalServer({root:resolve(root,'private'),staticDirectory:resolve('artifacts/p1c1/app')});
  13  |   origin=server.origin;
  14  | });
> 15  | test.afterAll(async()=>{await server.close();await rm(root,{recursive:true});});
      |                                      ^ TypeError: Cannot read properties of undefined (reading 'close')
  16  | test.beforeEach(async({page})=>{
  17  |   const response=await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  18  |   expect(response!.headers()['content-security-policy']).not.toContain('wasm-unsafe-eval');
  19  |   await page.waitForFunction(()=>!!(window as any).textFixture);
  20  | });
  21  | 
  22  | test('real worker Latin, combining, ligature and supplementary mapping', async ({page}, info) => {
  23  |   const errors:string[] = [], network:string[] = [];
  24  |   page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>network.push(r.url()));
  25  |   await page.goto(origin); await page.waitForFunction(()=>!!(window as any).textFixture);
  26  |   expect(network.some(u=>/wasm|\.ttf|\.otf|worker-/.test(u))).toBe(false);
  27  |   const result = await page.evaluate(()=> (window as any).textFixture.render('office A\u0301 🂡', ['NotoSans','NotoSansSymbols2']));
  28  |   expect(result.textUtf8).toBe('office A\u0301 🂡'); expect(result.frozen).toBe(true);
  29  |   expect(result.layout.utf16ToUtf8).toEqual([0,1,2,3,4,5,6,7,8,10,11,-1,15]);
  30  |   expect(result.layout.utf8ToUtf16).toEqual([0,1,2,3,4,5,6,7,8,-1,9,10,-1,-1,-1,12]);
  31  |   expect(result.layout.paragraphs[0].clusters.some((c:any)=>c.startUtf16===7&&c.endUtf16===9)).toBe(true);
  32  |   expect(result.layout.paragraphs[0].clusters.some((c:any)=>c.startUtf16===10&&c.endUtf16===12)).toBe(true);
  33  |   expect(result.layout.paragraphs[0].runs.reduce((n:number,r:any)=>n+r.glyphs.length,0)).toBeLessThan(11);
  34  |   expect(result.rgba.some((v:number,i:number)=>i%4===3&&v>0)).toBe(true);
  35  |   expect(result.lifecycle.activeWorkers).toBe(0);expect(errors).toEqual([]);
  36  |   expect(network.every(u=>new URL(u).origin===origin)).toBe(true);
  37  |   await info.attach('native-layout',{body:JSON.stringify({...result,rgba:undefined}),contentType:'application/json'});
  38  | });
  39  | 
  40  | test('real worker RTL per paragraph, bidi runs, CJK and exact retained bytes',async({page},info)=>{
  41  |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  42  |   const result=await page.evaluate(async()=>{
  43  |     const f=(window as any).textFixture; const a=await f.render('مرحبا ABC 123\n中文日本語', ['NotoSans','NotoSansArabic','NotoSansCJKsc']);
  44  |     const b=await f.render('مرحبا ABC 123\n中文日本語', ['NotoSans','NotoSansArabic','NotoSansCJKsc']);
  45  |     return {...a,repeatedRaster:b.rasterHash,repeatedLayout:b.layoutHash,repeatedDependency:b.dependencyHash};
  46  |   });
  47  |   expect(result.repeatedRaster).toBe(result.rasterHash);expect(result.repeatedLayout).toBe(result.layoutHash);
  48  |   expect(result.repeatedDependency).toBe(result.dependencyHash);
  49  |   const [rtl,cjk]=result.layout.paragraphs;
  50  |   expect([rtl.direction,cjk.direction]).toEqual(['rtl','ltr']);
  51  |   expect(rtl.clusters[0].rect[0]).toBeGreaterThan(rtl.clusters[4].rect[0]);
  52  |   expect(rtl.clusters.slice(6,9).map((c:any)=>c.direction)).toEqual(['ltr','ltr','ltr']);
  53  |   expect(rtl.runs.flatMap((r:any)=>r.offsetsUtf8)).toContain(8);
  54  |   expect(cjk.startUtf16).toBe(14);expect(cjk.startUtf8).toBe(19);
  55  |   expect(cjk.clusters.map((c:any)=>[c.startUtf16,c.endUtf16,c.startUtf8,c.endUtf8])).toEqual([[14,15,19,22],[15,16,22,25],[16,17,25,28],[17,18,28,31],[18,19,31,34]]);
  56  |   expect(new Set(result.layout.paragraphs.flatMap((p:any)=>p.runs.map((r:any)=>r.fontHash))).size).toBe(3);
  57  |   expect(result.allocation.gpuBytes).toBe(0);expect(result.allocation.wasmHeapBytes).toBeLessThanOrEqual(128*1024**2);
  58  |   await info.attach('layout',{body:JSON.stringify({...result,rgba:undefined}),contentType:'application/json'});
  59  | });
  60  | 
  61  | test('CPU straight alpha, fractional clip, wrapping, empty text and explicit direction',async({page},info)=>{
  62  |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  63  |   const output=await page.evaluate(async()=>{
  64  |     const f=(window as any).textFixture;
  65  |     async function draw(changes:any){const q=await f.request('MMMM\nMMMM');Object.assign(q,changes);const p=await f.renderer.prepare(q);return{hash:p.rasterHash,width:p.width,height:p.height,overflow:p.overflow,layout:JSON.parse(await p.layout.text()),pixels:Array.from(new Uint8Array(await p.rgba.arrayBuffer()))};}
  66  |     const q=await f.request('MMMM\nMMMM');
  67  |     const full=await draw({frame:{width:120,height:100}}),half=await draw({frame:{width:120,height:100},style:{...q.style,fill:[40,90,190,128]}});
  68  |     const clipped=await draw({frame:{width:120,height:20.5}}),zero=await draw({style:{...q.style,fill:[255,180,90,0]}});
  69  |     const empty=await draw({text:''}),wrap=await draw({frame:{width:40,height:300}}),rtl=await draw({text:'ABC',style:{...q.style,direction:'rtl'}});
  70  |     return{full,half,clipped,zero,empty,wrap,rtl};
  71  |   });
  72  |   const {full,half,clipped,zero,empty,wrap,rtl}=output;
  73  |   expect(full.overflow).toBe(false);expect(clipped.overflow).toBe(true);expect([clipped.width,clipped.height]).toEqual([120,21]);
  74  |   let opaque=0;
  75  |   for(let i=0;i<full.pixels.length;i+=4){
  76  |     if(full.pixels[i+3]===255){expect(full.pixels.slice(i,i+4)).toEqual([40,90,190,255]);expect(half.pixels.slice(i,i+4)).toEqual([40,90,190,128]);opaque++;}
  77  |     if(full.pixels[i+3]===0)expect(full.pixels.slice(i,i+4)).toEqual([0,0,0,0]);
  78  |   }
  79  |   expect(opaque).toBeGreaterThan(0);expect(zero.pixels.every((v:number)=>v===0)).toBe(true);expect(empty.pixels.every((v:number)=>v===0)).toBe(true);
  80  |   expect(empty.layout.paragraphs).toHaveLength(1);expect(wrap.layout.paragraphs[0].lines.length).toBeGreaterThan(1);
  81  |   expect(wrap.layout.logicalLines).toBe(2);expect(rtl.layout.paragraphs[0].direction).toBe('rtl');
  82  |   let fractional=false;
  83  |   for(let x=0;x<120;x++){const i=(20*120+x)*4;if(full.pixels[i+3]===255&&clipped.pixels[i+3]>0&&clipped.pixels[i+3]<255)fractional=true;}
  84  |   expect(fractional).toBe(true);
  85  |   await info.attach('pixel-controls',{body:JSON.stringify(Object.fromEntries(Object.entries(output).map(([k,v]:[string,any])=>[k,{...v,pixels:undefined}]))),contentType:'application/json'});
  86  | });
  87  | 
  88  | test('missing, corrupt, restricted, unreviewed and hash-mismatched fonts refuse preparation',async({page},info)=>{
  89  |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  90  |   const results=await page.evaluate(async()=>{
  91  |     const f=(window as any).textFixture, base=await f.request('ABC'), results:any={};
  92  |     async function check(key:string,q:any){try{await f.renderer.prepare(q);results[key]={accepted:true};}catch(e:any){results[key]={code:e.code,details:e.details};}}
  93  |     await check('missingGlyph',{...base,text:'𝄞'});
  94  |     await check('missingFont',{...base,fonts:[]});
  95  |     await check('hashMismatch',{...base,fonts:[{...base.fonts[0],bytes:new Blob(['bad'])}]});
  96  |     await check('unreviewed',{...base,fonts:[{...base.fonts[0],license:{hash:base.fonts[0].license.hash,embedding:'unknown'}}]});
  97  |     await check('faceIndex',{...base,fonts:[{...base.fonts[0],faceIndex:1}]});
  98  |     await check('unlistedFallback',{...base,style:{...base.style,explicitFallbacks:[base.fonts[0].hash]}});
  99  |     async function mutated(key:string,mutate:(b:ArrayBuffer)=>void){const b=await base.fonts[0].bytes.arrayBuffer();mutate(b);const bytes=new Blob([b]),hash=await f.hashBytes(bytes);await check(key,{...base,fonts:[{...base.fonts[0],bytes,hash}],style:{...base.style,primaryFont:hash}});}
  100 |     await mutated('corrupt',b=>new Uint8Array(b)[b.byteLength-12]^=1);
  101 |     await mutated('tableBounds',b=>new DataView(b).setUint32(20,b.byteLength+4));
  102 |     await mutated('restricted',b=>{
  103 |       const v=new DataView(b),u=new Uint8Array(b);
  104 |       for(let i=0;i<v.getUint16(4);i++){const at=12+i*16;if(String.fromCharCode(...u.slice(at,at+4))!=='OS/2')continue;
  105 |         const start=v.getUint32(at+8),length=v.getUint32(at+12);v.setUint16(start+8,2);let sum=0;
  106 |         for(let j=0;j<length;j+=4){let word=0;for(let k=0;k<4;k++)word=word*256+(j+k<length?u[start+j+k]:0);sum=(sum+word)>>>0;}v.setUint32(at+4,sum);
  107 |       }
  108 |     });
  109 |     return results;
  110 |   });
  111 |   expect(results.missingGlyph).toEqual({code:'TEXT_MISSING_GLYPHS',details:{codepoints:[0x1d11e]}});
  112 |   expect(results.missingFont.code).toBe('FONT_ORDER');expect(results.hashMismatch.code).toBe('FONT_HASH');
  113 |   expect(results.unreviewed.code).toBe('FONT_EMBEDDING_UNKNOWN');expect(results.faceIndex.code).toBe('FONT_FACE_INDEX');
  114 |   expect(results.unlistedFallback.code).toBe('FONT_ORDER');expect(results.corrupt.code).toBe('FONT_TABLE_CHECKSUM');
  115 |   expect(results.tableBounds.code).toBe('FONT_TABLE_BOUNDS');expect(results.restricted.code).toBe('FONT_EMBEDDING_RESTRICTED');
```
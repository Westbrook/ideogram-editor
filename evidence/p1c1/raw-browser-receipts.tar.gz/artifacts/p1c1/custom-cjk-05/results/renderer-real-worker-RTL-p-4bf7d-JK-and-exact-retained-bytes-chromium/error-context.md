# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker RTL per paragraph, bidi runs, CJK and exact retained bytes
- Location: tests/text/renderer.spec.ts:50:1

# Error details

```
Error: page.evaluate: Error: TEXT_WORKER_FAILURE "RangeError: TEXT_NATIVE_ALLOCATION"
    at http://127.0.0.1:57945/assets/index-XNdQ1e-C.js:1:39703
    at async Object.render (http://127.0.0.1:57945/assets/index-XNdQ1e-C.js:1:39668)
    at async eval (eval at evaluate (:311:30), <anonymous>:10:15)
    at async <anonymous>:337:30
```
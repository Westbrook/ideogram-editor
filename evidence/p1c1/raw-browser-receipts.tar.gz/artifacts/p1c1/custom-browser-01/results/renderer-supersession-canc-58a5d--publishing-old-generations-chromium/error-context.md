# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> supersession, cancel and dispose terminate owned workers without publishing old generations
- Location: tests/text/renderer.spec.ts:164:1

# Error details

```
Error: page.evaluate: TextFailure: TEXT_MEMORY_BUDGET
    at n (http://127.0.0.1:56704/assets/index-BipcmbRM.js:1:992)
    at Object.reserve (http://127.0.0.1:56704/assets/index-BipcmbRM.js:1:12390)
    at y.prepare (http://127.0.0.1:56704/assets/index-BipcmbRM.js:1:14037)
    at eval (eval at evaluate (:311:30), <anonymous>:5:31)
    at async <anonymous>:337:30
```
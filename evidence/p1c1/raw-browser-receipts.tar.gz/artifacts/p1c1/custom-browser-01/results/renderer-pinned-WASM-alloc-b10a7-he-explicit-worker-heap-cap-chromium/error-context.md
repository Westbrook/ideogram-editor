# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> pinned WASM allocator refuses growth above the explicit worker heap cap
- Location: tests/text/renderer.spec.ts:185:1

# Error details

```
Error: expect(received).toBeGreaterThan(expected)

Expected: > 0
Received:   0
```

# Test source

```ts
  87  |     if(full.pixels[i+3]===0)expect(full.pixels.slice(i,i+4)).toEqual([0,0,0,0]);
  88  |   }
  89  |   expect(opaque).toBeGreaterThan(0);expect(zero.pixels.every((v:number)=>v===0)).toBe(true);expect(empty.pixels.every((v:number)=>v===0)).toBe(true);
  90  |   expect(full.layout.requestedLineHeight).toBeCloseTo(full.layout.intrinsicHeight*1.2,6);
  91  |   expect(empty.layout.paragraphs).toHaveLength(1);expect(wrap.layout.paragraphs[0].lines.length).toBeGreaterThan(1);
  92  |   expect(wrap.layout.logicalLines).toBe(2);expect(rtl.layout.paragraphs[0].direction).toBe('rtl');
  93  |   let fractional=false;
  94  |   for(let x=0;x<120;x++){const i=(20*120+x)*4;if(full.pixels[i+3]===255&&clipped.pixels[i+3]>0&&clipped.pixels[i+3]<255)fractional=true;}
  95  |   expect(fractional).toBe(true);
  96  |   await info.attach('pixel-controls',{body:JSON.stringify(Object.fromEntries(Object.entries(output).map(([k,v]:[string,any])=>[k,{...v,pixels:undefined}]))),contentType:'application/json'});
  97  | });
  98  | 
  99  | test('missing, corrupt, restricted, unreviewed and hash-mismatched fonts refuse preparation',async({page},info)=>{
  100 |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  101 |   const results=await page.evaluate(async()=>{
  102 |     const f=(window as any).textFixture, base=await f.request('ABC'), results:any={};
  103 |     async function check(key:string,q:any){try{await f.renderer.prepare(q);results[key]={accepted:true};}catch(e:any){results[key]={code:e.code,details:e.details};}}
  104 |     await check('missingGlyph',{...base,text:'𝄞'});
  105 |     await check('missingFont',{...base,fonts:[]});
  106 |     await check('hashMismatch',{...base,fonts:[{...base.fonts[0],bytes:new Blob(['bad'])}]});
  107 |     await check('unreviewed',{...base,fonts:[{...base.fonts[0],license:{hash:base.fonts[0].license.hash,embedding:'unknown'}}]});
  108 |     await check('faceIndex',{...base,fonts:[{...base.fonts[0],faceIndex:1}]});
  109 |     await check('unlistedFallback',{...base,style:{...base.style,explicitFallbacks:[base.fonts[0].hash]}});
  110 |     async function mutated(key:string,mutate:(b:ArrayBuffer)=>void){const b=await base.fonts[0].bytes.arrayBuffer();mutate(b);const bytes=new Blob([b]),hash=await f.hashBytes(bytes);await check(key,{...base,fonts:[{...base.fonts[0],bytes,hash}],style:{...base.style,primaryFont:hash}});}
  111 |     await mutated('corrupt',b=>new Uint8Array(b)[b.byteLength-12]^=1);
  112 |     await mutated('tableBounds',b=>new DataView(b).setUint32(20,b.byteLength+4));
  113 |     await mutated('collection',b=>new DataView(b).setUint32(0,0x74746366));
  114 |     await mutated('variable',b=>new Uint8Array(b).set([102,118,97,114],12));
  115 |     await mutated('restricted',b=>{
  116 |       const v=new DataView(b),u=new Uint8Array(b);
  117 |       for(let i=0;i<v.getUint16(4);i++){const at=12+i*16;if(String.fromCharCode(...u.slice(at,at+4))!=='OS/2')continue;
  118 |         const start=v.getUint32(at+8),length=v.getUint32(at+12);v.setUint16(start+8,2);let sum=0;
  119 |         for(let j=0;j<length;j+=4){let word=0;for(let k=0;k<4;k++)word=word*256+(j+k<length?u[start+j+k]:0);sum=(sum+word)>>>0;}v.setUint32(at+4,sum);
  120 |       }
  121 |     });
  122 |     return results;
  123 |   });
  124 |   expect(results.missingGlyph).toEqual({code:'TEXT_MISSING_GLYPHS',details:{codepoints:[0x1d11e]}});
  125 |   expect(results.missingFont.code).toBe('FONT_ORDER');expect(results.hashMismatch.code).toBe('FONT_HASH');
  126 |   expect(results.unreviewed.code).toBe('FONT_EMBEDDING_UNKNOWN');expect(results.faceIndex.code).toBe('FONT_FACE_INDEX');
  127 |   expect(results.unlistedFallback.code).toBe('FONT_ORDER');expect(results.corrupt.code).toBe('FONT_TABLE_CHECKSUM');
  128 |   expect(results.tableBounds.code).toBe('FONT_TABLE_BOUNDS');expect(results.restricted.code).toBe('FONT_EMBEDDING_RESTRICTED');
  129 |   expect(results.collection.code).toBe('FONT_STATIC_SFNT_REQUIRED');expect(results.variable.code).toBe('FONT_UNSUPPORTED_TABLE');
  130 |   await info.attach('refusals',{body:JSON.stringify(results),contentType:'application/json'});
  131 | });
  132 | 
  133 | test('exact admission boundaries preserve input and reject unsafe indices and geometry',async({page})=>{
  134 |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  135 |   const result=await page.evaluate(async()=>{
  136 |     const f=(window as any).textFixture,q=await f.request('a'),cases:any={};
  137 |     for(const [name,text] of Object.entries({bytesAt:'x'.repeat(16384),bytesOver:'x'.repeat(16385),utf8At:'é'.repeat(8192),utf8Over:'é'.repeat(8193),linesAt:'\n'.repeat(255),linesOver:'\n'.repeat(256),surrogate:'\ud800',crlf:'a\r\nb',combining:'A\u0301'})){
  138 |       try{const i=f.textIndices(text);cases[name]={bytes:i.bytes,lines:i.lines};}catch(e:any){cases[name]=e.code;}
  139 |     }
  140 |     for(const [name,frame] of Object.entries({zero:{width:0,height:1},infinite:{width:Infinity,height:1},pixelsOver:{width:5000,height:5001},pixelsAt:{width:5000,height:5000}})){
  141 |       try{f.admitRequest({...q,frame});cases[name]='accepted';}catch(e:any){cases[name]=e.code;}
  142 |     }
  143 |     const font=q.fonts[0];
  144 |     for(const [name,fonts] of Object.entries({faceOver:[{...font,bytes:new Blob([new Uint8Array(16777217)])}],facesOver:Array.from({length:17},(_,i)=>({...font,hash:'sha256:'+i.toString(16).padStart(64,'0')}))})){
  145 |       try{f.admitRequest({...q,fonts,style:{...q.style,primaryFont:fonts[0].hash,explicitFallbacks:fonts.slice(1).map((x:any)=>x.hash)}});cases[name]='accepted';}catch(e:any){cases[name]=e.code;}
  146 |     }
  147 |     const maximum=new Blob([new Uint8Array(16777216)]),small=new Blob(['x']);
  148 |     for(const [name,blobs] of Object.entries({faceAt:[maximum],setAt:[maximum,maximum,maximum,maximum],setOver:[maximum,maximum,maximum,maximum,small],facesAt:Array(16).fill(small)})){
  149 |       const fonts=blobs.map((bytes:any,i:number)=>({...font,bytes,hash:'sha256:'+i.toString(16).padStart(64,'0')}));
  150 |       try{f.admitRequest({...q,fonts,style:{...q.style,primaryFont:fonts[0].hash,explicitFallbacks:fonts.slice(1).map((x:any)=>x.hash)}});cases[name]='accepted';}catch(e:any){cases[name]=e.code;}
  151 |     }
  152 |     cases.directions=['123 مرحبا','ABC مرحبا','\u2067مرحبا\u2069 ABC','123'].map(f.paragraphDirection);
  153 |     return cases;
  154 |   });
  155 |   expect(result.bytesAt.bytes).toBe(16384);expect(result.bytesOver).toBe('TEXT_BYTES');expect(result.utf8At.bytes).toBe(16384);expect(result.utf8Over).toBe('TEXT_BYTES');
  156 |   expect(result.linesAt.lines).toBe(256);expect(result.linesOver).toBe('TEXT_LINES');expect(result.surrogate).toBe('TEXT_SURROGATE');expect(result.crlf).toBe('TEXT_REQUIRES_REVIEWED_LF_CONVERSION');
  157 |   expect(result.combining.bytes).toBe(3);expect(result.pixelsAt).toBe('accepted');
  158 |   for(const k of ['zero','infinite','pixelsOver'])expect(result[k]).toBe('TEXT_FRAME');
  159 |   expect(result.faceOver).toBe('FONT_SIZE');expect(result.facesOver).toBe('FONT_ORDER');
  160 |   for(const key of ['faceAt','setAt','facesAt'])expect(result[key]).toBe('accepted');expect(result.setOver).toBe('FONT_SET_SIZE');
  161 |   expect(result.directions).toEqual(['rtl','ltr','ltr','ltr']);
  162 | });
  163 | 
  164 | test('supersession, cancel and dispose terminate owned workers without publishing old generations',async({page},info)=>{
  165 |   await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  166 |   const workers:{url:string;closed:boolean}[]=[];
  167 |   page.on('worker',w=>{const entry={url:w.url(),closed:false};workers.push(entry);w.on('close',()=>entry.closed=true);});
  168 |   const result=await page.evaluate(async()=>{
  169 |     const f=(window as any).textFixture,q=await f.request('first');
  170 |     const first=f.renderer.prepare(q).then(()=> 'unexpected', (e:any)=>e.code);
  171 |     const second=f.renderer.prepare({...q,text:'second',token:{...q.token,generation:q.token.generation+1}});
  172 |     const current=await second,firstResult=await first;
  173 |     const cancelled=f.renderer.prepare(q).then(()=> 'unexpected',(e:any)=>e.code);f.renderer.cancel();
  174 |     const cancelResult=await cancelled;
  175 |     const disposed=f.renderer.prepare(q).then(()=> 'unexpected',(e:any)=>e.code);f.renderer.dispose();
  176 |     const disposeResult=await disposed;
  177 |     let after='';try{await f.renderer.prepare(q);}catch(e:any){after=e.code;}
  178 |     return{firstResult,cancelResult,disposeResult,after,text:await current.textUtf8.text(),generation:current.token.generation,lifecycle:f.renderer.lifecycle};
  179 |   });
  180 |   expect(result.firstResult).toBe('TEXT_STALE');expect(result.cancelResult).toBe('TEXT_CANCELLED');expect(result.disposeResult).toBe('TEXT_CANCELLED');expect(result.after).toBe('TEXT_DISPOSED');
  181 |   expect(result.text).toBe('second');expect(result.generation).toBe(2);expect(result.lifecycle).toEqual({activeWorkers:0,terminations:4,disposed:true});
  182 |   await info.attach('lifecycle',{body:JSON.stringify({result,workers,resetCalls:0,storage:'No origin storage written or reset by functional fixture.'}),contentType:'application/json'});
  183 | });
  184 | 
  185 | test('pinned WASM allocator refuses growth above the explicit worker heap cap',async({page},info)=>{
  186 |   const result=await page.evaluate(()=>(window as any).textFixture.heapControl());
> 187 |   expect(result.error).toBeUndefined();expect(result.pointer).toBeGreaterThan(0);
      |                                                               ^ Error: expect(received).toBeGreaterThan(expected)
  188 |   expect(result.overPointer).toBe(0);expect(result.final).toBeLessThanOrEqual(128*1024**2);
  189 |   expect(result.before).toBe(128*1024**2);expect(result.after).toBe(result.before);
  190 |   await info.attach('heap-admission',{body:JSON.stringify(result),contentType:'application/json'});
  191 | });
  192 | 
  193 | test('stock native storage reset requires observed closure of every actual text worker',async({playwright,browserName},info)=>{
  194 |   const profile=browserName==='webkit'?await mkdtemp(resolve(await realpath(tmpdir()),'ie-text-worker-')):undefined;
  195 |   const browser=profile?undefined:await playwright[browserName].launch();
  196 |   const context=profile?await playwright.webkit.launchPersistentContext(profile):await browser!.newContext();
  197 |   await Promise.all(context.pages().map(p=>p.close()));
  198 |   const storage=await ownedOPFS(context,profile??browserName+' ephemeral');
  199 |   const page=await context.newPage(),workers:{url:string;closed:boolean}[]=[],errors:string[]=[];
  200 |   page.on('pageerror',e=>errors.push(e.message));
  201 |   page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
  202 |   page.on('worker',w=>{const entry={url:w.url(),closed:false};workers.push(entry);w.on('close',()=>entry.closed=true);});
  203 |   let outcome='incomplete',error:string|null=null;
  204 |   const marker='text-worker-'+randomUUID();
  205 |   try{
  206 |     await storage.admit(page,origin);await page.goto(origin);await page.waitForFunction(()=>!!(window as any).textFixture);
  207 |     await page.evaluate(async name=>{
  208 |       const root=await navigator.storage.getDirectory(),file=await root.getFileHandle(name,{create:true}),writer=await file.createWritable();
  209 |       await writer.write('Owned worker cleanup control');await writer.close();
  210 |       const f=(window as any).textFixture,q=await f.request('native worker cleanup');
  211 |       await f.renderer.prepare(q);
  212 |       try{await f.renderer.prepare({...q,text:'𝄞'});}catch(e:any){if(e.code!=='TEXT_MISSING_GLYPHS')throw e;}
  213 |     },marker);
  214 |     const workerStarted=page.waitForEvent('worker');
  215 |     await page.evaluate(async()=>{
  216 |       const f=(window as any).textFixture,q=await f.request('cancel real worker');
  217 |       (window as any).pendingText=f.renderer.prepare(q).catch((e:any)=>e.code);
  218 |     });
  219 |     await workerStarted;
  220 |     const cancellation=await page.evaluate(async()=>{
  221 |       const f=(window as any).textFixture;f.renderer.cancel();f.renderer.dispose();return await (window as any).pendingText;
  222 |     });
  223 |     expect(cancellation).toBe('TEXT_CANCELLED');
  224 |     expect(workers.length).toBeGreaterThan(0);
  225 |     try{await storage.cleanup();storage.verify();outcome='clean';}catch(e){error=String(e);}
  226 |     const reset=storage.ledger.filter((x:any)=>x.phase==='public-reset');
  227 |     if(outcome==='clean'){
  228 |       expect(workers.every(w=>w.closed)).toBe(true);expect(reset).toHaveLength(1);
  229 |       expect(storage.ledger.some((x:any)=>x.phase==='post-reset'&&x.entries.length===0)).toBe(true);
  230 |     }else{
  231 |       expect(reset).toHaveLength(0);
  232 |       expect(storage.ledger.some((x:any)=>x.phase==='cleanup-incomplete')).toBe(true);
  233 |       info.annotations.push({type:'cleanup-incomplete',description:error+'; no reset; owned marker absence unclaimed'});
  234 |     }
  235 |     expect(errors).toEqual([]);
  236 |   }finally{
  237 |     await info.attach('native-worker-cleanup',{body:JSON.stringify({browserName,origin,marker,outcome,error,workers,errors,ledger:storage.ledger},null,2),contentType:'application/json'});
  238 |     await context.close();await browser?.close();
  239 |     if(profile&&outcome==='clean')await rm(profile,{recursive:true});
  240 |   }
  241 | });
  242 | 
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker RTL per paragraph, bidi runs, CJK and exact retained bytes
- Location: tests/text/renderer.spec.ts:50:1

# Error details

```
Error: page.evaluate: Error: TEXT_WORKER_FAILURE "RuntimeError: memory access out of bounds"
    at http://127.0.0.1:56685/assets/index-BipcmbRM.js:1:39195
    at async Object.render (http://127.0.0.1:56685/assets/index-BipcmbRM.js:1:39160)
    at async eval (eval at evaluate (:311:30), <anonymous>:4:15)
    at async <anonymous>:337:30
```
# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> stock native storage reset requires observed closure of every actual text worker
- Location: tests/text/renderer.spec.ts:193:1

# Error details

```
Test timeout of 60000ms exceeded.
```

# Page snapshot

```yaml
- paragraph [ref=e2]: Native text foundation fixture
```
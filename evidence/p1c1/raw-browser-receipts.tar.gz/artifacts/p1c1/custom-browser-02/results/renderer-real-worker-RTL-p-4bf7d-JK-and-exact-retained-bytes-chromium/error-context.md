# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker RTL per paragraph, bidi runs, CJK and exact retained bytes
- Location: tests/text/renderer.spec.ts:50:1

# Error details

```
Error: page.evaluate: Error: TEXT_WORKER_FAILURE "RangeError: TEXT_NATIVE_ALLOCATION"
    at http://127.0.0.1:57332/assets/index-DM0mFoGM.js:1:39399
    at async Object.render (http://127.0.0.1:57332/assets/index-DM0mFoGM.js:1:39364)
    at async eval (eval at evaluate (:311:30), <anonymous>:4:15)
    at async <anonymous>:337:30
```
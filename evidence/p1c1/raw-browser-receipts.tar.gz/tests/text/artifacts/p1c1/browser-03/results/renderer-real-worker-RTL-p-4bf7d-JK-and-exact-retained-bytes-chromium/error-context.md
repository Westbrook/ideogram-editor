# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker RTL per paragraph, bidi runs, CJK and exact retained bytes
- Location: tests/text/renderer.spec.ts:43:1

# Error details

```
Error: page.evaluate: Error: TEXT_LAYOUT_INDEX {"byte":5,"text":"中文日本語","metrics":[{"startIndex":0,"endIndex":5,"endExcludingWhitespaces":5,"endIncludingNewline":5,"isHardBreak":true,"ascent":33.152000427246094,"descent":5.2480010986328125,"height":38,"width":160.00030517578125,"left":0,"baseline":32.75199890136719,"lineNumber":0}]}
    at http://127.0.0.1:64724/assets/index-CWxI8d6c.js:1:31131
    at async Object.render (http://127.0.0.1:64724/assets/index-CWxI8d6c.js:1:31096)
    at async eval (eval at evaluate (:311:30), <anonymous>:3:15)
    at async <anonymous>:337:30
```
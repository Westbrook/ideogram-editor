# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker Latin, combining, ligature and supplementary mapping
- Location: tests/text/renderer.spec.ts:25:1

# Error details

```
Error: page.evaluate: Error: TEXT_LAYOUT_INDEX {"byte":12,"text":"office Á 🂡","metrics":[{"startIndex":0,"endIndex":12,"endExcludingWhitespaces":12,"endIncludingNewline":12,"isHardBreak":true,"ascent":31.61600112915039,"descent":12.176000595092773,"height":44,"width":141.76031494140625,"left":0,"baseline":31.823999404907227,"lineNumber":0}]}
    at http://127.0.0.1:64711/assets/index-CWxI8d6c.js:1:31131
    at async Object.render (http://127.0.0.1:64711/assets/index-CWxI8d6c.js:1:31096)
    at async <anonymous>:337:30
```
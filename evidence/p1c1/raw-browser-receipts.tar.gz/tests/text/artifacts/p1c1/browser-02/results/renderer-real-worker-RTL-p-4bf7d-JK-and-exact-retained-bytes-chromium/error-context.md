# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker RTL per paragraph, bidi runs, CJK and exact retained bytes
- Location: tests/text/renderer.spec.ts:43:1

# Error details

```
Error: page.evaluate: TextFailure: TEXT_LAYOUT_INDEX
    at s.onmessage (http://127.0.0.1:64598/assets/index-BjBCU8gi.js:1:4428)
```
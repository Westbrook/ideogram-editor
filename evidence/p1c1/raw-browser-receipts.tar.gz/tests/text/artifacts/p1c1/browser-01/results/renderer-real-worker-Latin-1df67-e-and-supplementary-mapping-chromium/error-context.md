# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: renderer.spec.ts >> real worker Latin, combining, ligature and supplementary mapping
- Location: tests/text/renderer.spec.ts:25:1

# Error details

```
Error: page.evaluate: TextFailure: TEXT_MISSING_GLYPHS
    at s.onmessage (http://127.0.0.1:64506/assets/index-BjBCU8gi.js:1:4428)
```
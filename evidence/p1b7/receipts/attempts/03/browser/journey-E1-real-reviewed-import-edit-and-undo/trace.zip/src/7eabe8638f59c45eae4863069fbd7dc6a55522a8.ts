import {test,expect} from '@playwright/test';
import {mkdtemp,realpath} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,resolve} from 'node:path';
import {pathToFileURL} from 'node:url';
const {startLocalServer}=await import(pathToFileURL(resolve('dist/local/server/http.js')).href);
test('E1 real reviewed import, edit and undo',async({page,context})=>{
 const directory=await mkdtemp(join(await realpath(tmpdir()),'ie-integrated-'));
 const server=await startLocalServer({root:join(directory,'private'),staticDirectory:resolve('dist/app'),credentialConfigured:false});
 const errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('console',m=>{if(m.type()==='error')errors.push(m.text());});
 page.on('request',request=>expect(new URL(request.url()).hostname).toBe('127.0.0.1'));
 page.on('requestfailed',request=>console.log('failed request',new URL(request.url()).pathname,request.failure()));
 try{
 await page.goto(server.issuePairingURL());await expect(page.getByText('Local recovery complete. Accepted edits are saved locally.',{exact:true})).toBeVisible();
 await page.locator('en-file-upload input[type=file]').setInputFiles('tests/raster/fixtures/hidden-alpha.png');
 await expect(page.getByRole('dialog',{name:'Review image conversion'})).toBeVisible();
 await expect(page.getByText('No document open',{exact:true})).toBeVisible();
 await page.getByRole('button',{name:'Apply reviewed result',exact:true}).click();
 await expect(page.getByText('ImportAsset accepted and saved locally.',{exact:true})).toBeVisible();
 await expect(page.locator('canvas')).not.toHaveAttribute('data-asset','');
 await page.getByRole('treeitem').first().click();
 await expect(page.getByRole('textbox',{name:'Layer name',exact:true})).toHaveValue('hidden-alpha.png');
 await page.getByRole('spinbutton',{name:'Opacity (0–1)',exact:true}).fill('0.5');
 await page.getByRole('button',{name:'Apply properties',exact:true}).click();
 await expect(page.getByText('SetLayerProperties accepted and saved locally.',{exact:true})).toBeVisible();
 await page.getByRole('button',{name:'Undo',exact:true}).click();
 await expect(page.getByText('Undo accepted and saved locally.',{exact:true})).toBeVisible();
 await expect(page.getByText(/Updates interrupted/)).toHaveCount(0);
 await page.screenshot({path:(process.env.EDITOR_RECEIPT??'artifacts/p1b7/current')+'/editor.png'});
 expect(errors).toEqual([]);
 }finally{await server.close();}
});

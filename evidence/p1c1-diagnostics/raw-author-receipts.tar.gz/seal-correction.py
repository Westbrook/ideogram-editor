from pathlib import Path
import json,hashlib,subprocess,tarfile,base64,datetime,shutil
repo=Path('/Users/westbrook/Documents/repos/ideogram-edit');root=Path(__file__).resolve().parent;source=root/'source';review=Path('/Users/westbrook/Documents/repos/ideogram-edit-p1c1-review-b7998c3-20260926T211116Z');out=repo/'evidence/p1c1-diagnostics';out.mkdir(exist_ok=True)
old='b7998c35299ebc32c3c5e5544c8b5cbbdbd322c5';head='e78e1e733a92901e0c717085d74ef60f816e1706';sha=lambda b:hashlib.sha256(b).hexdigest();now=datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(name,value):(out/name).write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip()==head
assert not subprocess.check_output(['git','status','--porcelain'],cwd=source,text=True).strip()
files=subprocess.check_output(['git','ls-files','-z'],cwd=repo).decode().split('\0')[:-1]
selected=[p for p in files if p.startswith(('src/','server/','tests/','tooling/','vendor/')) or p in ['package.json','package-lock.json','tsconfig.json','tsconfig.app.json','tsconfig.server.json','vite.config.ts','vite.app.config.ts','.progress-report/project.json']]
identities=[]
for p in selected:
 b=(source/p).read_bytes();assert b==(repo/p).read_bytes(),p
 original=subprocess.check_output(['git','show',head+':'+p],cwd=repo);assert b==original,p
 identities.append({'path':p,'bytes':len(b),'sha256':sha(b)})
changed=subprocess.check_output(['git','diff','--name-only',old,head],cwd=repo,text=True).splitlines()
assert changed==['src/text/engine.ts','src/text/profile.json','tests/text/renderer.spec.ts','vendor/text/FILES.json','vendor/text/manifest.json'],changed
native=[x for x in identities if (x['path'].startswith(('tooling/text/','vendor/text/')) and x['path'] not in changed) or x['path'] in ['package.json','package-lock.json','tooling/bootstrap-toolchain.py','tooling/toolchain.json']]
host=[x for x in identities if x['path'].startswith(('server/','tests/session/')) or x['path'] in ['tests/text/host.test.mjs','tests/editor/owned-opfs.ts','tsconfig.server.json']]
for row in native+host:assert row['sha256']==sha(subprocess.check_output(['git','show',old+':'+row['path']],cwd=repo)),row['path']
put('source-identity.json',{'at':now,'executedSourceCommit':head,'rejectedPredecessor':old,'changedFiles':changed,'freshCheckoutClean':True,'worktreeEqualsExecutedGitInputs':True,'files':identities,'unchangedNativeOwningInputs':native,'unchangedHostSessionOwningInputs':host})
logs=[json.loads(p.read_text()) for p in sorted((root/'logs').glob('*.json'))];assert len(logs)==12 and all(x['exitCode']==0 for x in logs)
checks=[];diagnostics=[];storage=[]
for directory in sorted((root/'browser').iterdir()):
 p=directory/'results.json'
 if not p.exists():continue
 d=json.loads(p.read_text());assert d['stats']['expected']==14 and not any(d['stats'][k] for k in ['unexpected','flaky','skipped'])
 checks.append({'engine':directory.name.split('-')[-1],'stats':d['stats']})
 for suite in d['suites']:
  for spec in suite.get('specs',[]):
   for test in spec['tests']:
    for result in test['results']:
     for attachment in result['attachments']:
      if attachment['name'] in ['affected-codepoint-diagnostics','native-worker-cleanup']:
       value={'engine':directory.name.split('-')[-1],'attachment':json.loads(base64.b64decode(attachment['body']))}
       (diagnostics if attachment['name']=='affected-codepoint-diagnostics' else storage).append(value)
assert len(checks)==len(diagnostics)==len(storage)==3
put('diagnostics.json',diagnostics);put('native-storage-reset.json',storage)
controls=[json.loads(p.read_text()) for p in sorted(root.glob('controls-v4-*-focused.json'))];assert len(controls)==3 and all(len(c['checks'])==1 and c['checks'][0]['status']=='PASS' and not c['errors'] for c in controls)
put('external-controls.json',controls)
reviewSeal=json.loads((review/'FILES.json').read_text());reviewFiles=[]
for row in reviewSeal['files']:
 p=row['path']
 if p.startswith('controls-') or p in ['helper-correction.txt','verdict.txt','final-diagnostic-oracle.json','summary.json','identity-audit.json']:
  b=(review/p).read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];reviewFiles.append(row)
with tarfile.open(out/'reviewer-diagnostic-history.tar.gz','w:gz') as t:
 for row in reviewFiles:t.add(review/row['path'],arcname=row['path'])
 t.add(review/'FILES.json',arcname='FILES.json')
put('preserved-reviewer-history.json',{'originalRoot':str(review),'originalTarget':old,'originalVerdict':'NOT APPROVED','originalSealSHA256':sha((review/'FILES.json').read_bytes()),'scope':'Exact diagnostic-related subset of the sealed independent review, not a new review or complete copy of its declared set. All original files remain at originalRoot. Includes v1/v2 mistaken oracles, v3 actual false diagnosis and durable v4.','copiedEntries':reviewFiles})
with tarfile.open(out/'raw-author-receipts.tar.gz','w:gz') as t:
 for p in [root/'logs',root/'browser',root/'run.py',root/'reviewer-inputs.json',root/'seal-correction.py']+sorted(root.glob('controls-v4-*-focused.json')):t.add(p,arcname=str(p.relative_to(root)))
 t.add(repo/'artifacts/p1c1-diagnostics/initial-focused',arcname='initial-focused')
 t.add(repo/'artifacts/p1c1-diagnostics/initial-focused.txt',arcname='initial-focused.txt')
shutil.copy2(root/'controls-v4.mjs',out/'controls-v4.mjs')
(out/'source.patch').write_bytes(subprocess.check_output(['git','diff',old,head],cwd=repo))
oldSummary=json.loads((repo/'evidence/p1c1/summary.json').read_text());profile=json.loads((repo/'src/text/profile.json').read_text())
put('summary.json',{'at':now,'task':'37acc962-c349-497b-977c-71c881390331','status':'AUTHOR correction verification complete; review_required; exact evidence successor recorded in task/PR handoff','branch':'ideogram-editor-p1','approvedBase':'b3173ff73707eb2e9595be6c941c2afc3df1093c','rejectedPredecessor':old,'executedSourceCommit':head,'profile':profile['id'],'changedFiles':changed,'correction':'Glyph zero fallback refusal uses native visitor UTF8 index and native glyph-info UTF16 grapheme range to collect affected source scalars/ranges. Existing native unresolved list, complete input/rendering, font identity and caps remain unchanged. No new TAB rendering/width policy.','gates':logs,'stockRendererChecks':checks,'externalControls':'3/3 sealed controls-v4 missing-glyph author executions PASS','initialCheck':'1 Chromium focused author regression PASS before fresh checkout; raw retained separately','sourceIdentity':'source-identity.json','rawArchive':'raw-author-receipts.tar.gz','historyArchive':'reviewer-diagnostic-history.tar.gz','reusedUnchangedHostSessionGates':oldSummary['reusedUnchangedHostSessionGates'],'reusedNativeRebuild':oldSummary['nativeRebuild'],'nativeRebuildReuseReason':'Native JS/WASM, recipe, source closure, tools, fonts and owning package inputs exactly unchanged from b7998c3. No native rebuild during this adapter-only correction; previous author custom.3 exact reproduction remains source-qualified. Independent predecessor review separately verified same native bytes from reacquired sources on same host; its overall verdict remains NOT APPROVED.','limits':['All new executions are AUTHOR; no independent successor acceptance or P1c credit.','A-R01 remains open; logical reservation checks do not qualify process RSS, broad resources, timing or platform/IME/AT behavior.','External focused v4 WebKit/Firefox worker close observations are false; context/browser close completed but no reset was performed. These observations are not native-close receipts. Dedicated supplied storage gates are separate and retain their actual close/reset evidence.','No writer/schema/UI/provider/service/default/branch changes. Existing evidence/p1c1 and original reviewer directory remain unchanged.','Native unresolvedCodepoints retains its upstream affected-cluster semantics; new ranges are the native glyph-zero fallback graphemes, not a per-codepoint cmap coverage claim.'],'newFailures':[]})
(out/'REVERIFY.txt').write_text('''P1c.1 affected-codepoint correction — reproducible handoff

Executed source: e78e1e733a92901e0c717085d74ef60f816e1706.
The final evidence successor has identical runtime/test inputs, checked in source-identity.json.
Create a new detached checkout of that final exact commit. Use a task-owned parent directory.
Copy evidence/p1c1-diagnostics/controls-v4.mjs to the checkout parent (../controls-v4.mjs).
Keep the original rejected review and all existing services/evidence unchanged.

python3 tooling/bootstrap-toolchain.py
export PATH="$PWD/.toolchain/bin:$PATH"
npm ci
npm run verify:text
npm run typecheck
npm run build
npx vite build --config tests/text/vite.config.ts
node ../controls-v4.mjs chromium missing-glyph
node ../controls-v4.mjs webkit missing-glyph
node ../controls-v4.mjs firefox missing-glyph
TEXT_RECEIPT=../review-browser-webkit npx playwright test --config tests/text/playwright.config.ts --project=webkit
TEXT_RECEIPT=../review-browser-chromium npx playwright test --config tests/text/playwright.config.ts --project=chromium
TEXT_RECEIPT=../review-browser-firefox npx playwright test --config tests/text/playwright.config.ts --project=firefox

Run engines serially with unique receipt paths. These are bounded correctness checks, not a timing/resource campaign.
Source-qualified native/host reuse: source-identity.json pins unchanged owning inputs; summary.json names existing author native and host/session receipts. Native/recipe modification requires its own reproduction.
Original review diagnostic subset and mistaken v1/v2 helper history are exact archived bytes, not relabelled passes. Raw current logs include timestamps, command, cwd, source SHA and toolchain path; initial Chromium focus is separate.
Current native glyph-zero ranges use UTF8 shape offsets and UTF16 native graphemes, including RTL and supplementary mappings. Native getGlyphInfoAt plus scalar boundary checks determine ranges; no manual TAB list, glyph substitution, normalized text, narrowed input or capped layout is used.
''')
seal=[]
for p in sorted(out.iterdir()):
 if p.name=='FILES.json':continue
 b=p.read_bytes();seal.append({'path':str(p.relative_to(repo)),'bytes':len(b),'sha256':sha(b)})
put('FILES.json',{'at':now,'executedSourceCommit':head,'profile':profile['id'],'files':seal})
print(json.dumps({'files':len(seal),'bytes':sum(r['bytes'] for r in seal),'profile':profile['id'],'checks':checks,'sourceInputs':len(identities),'nativeReuseInputs':len(native),'hostReuseInputs':len(host)},indent=2))

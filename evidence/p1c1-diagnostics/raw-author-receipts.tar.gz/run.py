import subprocess,datetime,json,os,sys
from pathlib import Path
root=Path(__file__).resolve().parent
name=sys.argv[1];cmd=sys.argv[2:];source=root/'source'
now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
env={**os.environ,'PATH':str(source/'.toolchain/bin')+os.pathsep+os.environ['PATH'],'TEXT_RECEIPT':str(root/'browser'/name)}
r={'command':cmd,'cwd':str(source),'start':now(),'sourceCommit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=source,text=True).strip(),'TEXT_RECEIPT':env['TEXT_RECEIPT'],'PATH_prefix':str(source/'.toolchain/bin')}
with (root/'logs'/f'{name}.txt').open('w') as f:
 p=subprocess.run(cmd,cwd=source,env=env,stdout=f,stderr=subprocess.STDOUT)
r.update(end=now(),exitCode=p.returncode)
(root/'logs'/f'{name}.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r),flush=True)
print((root/'logs'/f'{name}.txt').read_text()[-4000:],flush=True)
sys.exit(p.returncode)
